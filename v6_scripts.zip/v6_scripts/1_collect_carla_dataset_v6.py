import csv
import importlib
import math
import random
import sys
import time
import traceback
import zipfile
from collections import deque
from pathlib import Path


def resolve_v6_root() -> Path:
    script_path = Path(__file__).resolve()
    for parent in [script_path.parent, *script_path.parents]:
        if parent.name == "v6":
            return parent
    for parent in script_path.parents:
        candidate = parent / "v6"
        if candidate.exists():
            return candidate
    return script_path.parent / "v6"

V6_ROOT = resolve_v6_root()
HOST_PROJECT_ROOT = V6_ROOT.parent


def resolve_default_dataset_dir() -> Path:
    return V6_ROOT / "datasets" / "carla_tabular_dataset_v6"


def load_carla_api():
    try:
        imported_carla = importlib.import_module("carla")
        if hasattr(imported_carla, "Client") and hasattr(imported_carla, "WeatherParameters"):
            return imported_carla
    except Exception:
        pass

    wheel_candidates = sorted((HOST_PROJECT_ROOT / "carla" / "dist").glob("carla-*.whl"))
    if not wheel_candidates:
        raise ImportError(
            "CARLA Python wheel could not be found under PythonAPI/carla/dist. "
            "Install the wheel or keep the distributed wheel in that folder."
        )

    wheel_path = wheel_candidates[-1]
    extract_root = V6_ROOT / ".carla_api_cache" / wheel_path.stem
    carla_package_dir = extract_root / "carla"

    if not (carla_package_dir / "__init__.py").exists():
        extract_root.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(wheel_path) as wheel_file:
            wheel_file.extractall(extract_root)

    extract_root_str = str(extract_root)
    if extract_root_str not in sys.path:
        sys.path.insert(0, extract_root_str)

    sys.modules.pop("carla", None)
    importlib.invalidate_caches()
    imported_carla = importlib.import_module("carla")

    if not hasattr(imported_carla, "Client") or not hasattr(imported_carla, "WeatherParameters"):
        raise ImportError(
            "The imported 'carla' module is not the CARLA simulator API. "
            "Check the active interpreter and CARLA wheel installation."
        )

    return imported_carla


carla = load_carla_api()


DATASET_DIR = resolve_default_dataset_dir()
RAW_DIR = DATASET_DIR / "raw"
RAW_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_FILE = RAW_DIR / "carla_raw_dataset.csv"

HOST = "127.0.0.1"
PORT = 2000
TIMEOUT = 10.0

FPS = 20
RUNS_PER_ATTACK_CLASS = 20
TICKS_PER_RUN = 150
WARMUP_TICKS = 20
NPC_LIMIT_RANGE = (20, 38)
NEARBY_RADIUS = 50.0
MAX_RUN_RETRIES = 3

ATTACK_TYPES = [
    "normal",
    "gps_spoofing",
    "position_spoofing",
    "speed_spoofing",
    "sudden_brake",
    "lane_deviation",
    "sensor_noise",
    "dos",
    "delayed_sensor_attack",
    "heading_spoofing",
]

ATTACK_ONLY_TYPES = [attack_type for attack_type in ATTACK_TYPES if attack_type != "normal"]

CLASS_MAP = {
    "normal": 0,
    "gps_spoofing": 1,
    "position_spoofing": 2,
    "speed_spoofing": 3,
    "sudden_brake": 4,
    "lane_deviation": 5,
    "sensor_noise": 6,
    "dos": 7,
    "delayed_sensor_attack": 8,
    "heading_spoofing": 9,
}

NORMAL_SUBTYPES = [
    "normal_smooth_drive",
    "normal_stop_and_go",
    "normal_soft_brake",
    "normal_hard_brake_safe",
    "normal_lane_change_safe",
    "normal_turning",
    "normal_intersection_approach",
    "normal_dense_traffic",
    "normal_rain",
    "normal_night_or_low_light",
]

GPS_SPOOF_SUBTYPES = [
    "gps_slow_drift",
    "gps_directional_drift",
    "gps_curved_drift",
    "gps_lane_inconsistent_drift",
    "gps_map_inconsistent_drift",
]

OBS_KEYS = ("x", "y", "z", "speed", "accel", "yaw")
WEATHER_PRESETS = {
    "clear_noon": ("ClearNoon", carla.WeatherParameters.ClearNoon),
    "cloudy_noon": ("CloudyNoon", carla.WeatherParameters.CloudyNoon),
    "wet_noon": ("WetNoon", carla.WeatherParameters.WetNoon),
    "wet_cloudy_noon": ("WetCloudyNoon", carla.WeatherParameters.WetCloudyNoon),
    "soft_rain_noon": ("SoftRainNoon", carla.WeatherParameters.SoftRainNoon),
    "mid_rain_noon": ("MidRainyNoon", carla.WeatherParameters.MidRainyNoon),
    "clear_sunset": ("ClearSunset", carla.WeatherParameters.ClearSunset),
}

RAIN_WEATHER_KEYS = ("soft_rain_noon", "mid_rain_noon", "wet_cloudy_noon")
LOW_LIGHT_WEATHER_KEYS = ("clear_sunset",)

FIELDNAMES = [
    "timestamp",
    "frame",
    "scenario_id",
    "run_id",
    "attack_run_id",
    "class_run_id",
    "tick_in_run",
    "vehicle_id",
    "map_name",
    "weather_preset",
    "npc_vehicle_count",
    "attack_type",
    "normal_subtype",
    "gps_spoof_subtype",
    "binary_label",
    "multiclass_label",
    "real_x",
    "real_y",
    "real_z",
    "real_speed",
    "real_accel",
    "real_yaw",
    "obs_x",
    "obs_y",
    "obs_z",
    "obs_speed",
    "obs_accel",
    "obs_yaw",
    "road_id",
    "lane_id",
    "throttle",
    "brake",
    "steer",
    "delta_pos_x",
    "delta_pos_y",
    "delta_speed",
    "delta_accel",
    "yaw_error",
    "is_missing",
    "nearest_vehicle_distance",
    "nearest_vehicle_relative_speed",
    "front_vehicle_distance",
    "rear_vehicle_distance",
    "nearby_vehicle_count",
    "traffic_density",
    "speed_change_rate",
    "acceleration_change_rate",
    "yaw_change_rate",
    "position_jump",
    "gps_drift_magnitude",
    "gps_drift_rate",
    "position_jump_magnitude",
    "position_jump_flag",
    "hard_brake_flag",
    "brake_intensity",
    "deceleration_rate",
    "time_since_brake_start",
    "speed_spoof_ratio",
    "speed_spoof_offset",
    "missing_ratio",
    "stale_packet_flag",
    "packet_delay_steps",
    "sensor_delay_steps",
    "delayed_sensor_flag",
    "heading_spoof_offset",
    "heading_spoof_flag",
]


def build_run_plan():
    run_plan = {attack_type: RUNS_PER_ATTACK_CLASS for attack_type in ATTACK_ONLY_TYPES}
    run_plan["normal"] = RUNS_PER_ATTACK_CLASS * len(ATTACK_ONLY_TYPES)
    return run_plan


def speed_mps(vehicle):
    velocity = vehicle.get_velocity()
    return math.sqrt(velocity.x ** 2 + velocity.y ** 2 + velocity.z ** 2)


def longitudinal_accel_mps2(vehicle):
    acceleration = vehicle.get_acceleration()
    yaw_rad = math.radians(vehicle.get_transform().rotation.yaw)
    forward_x = math.cos(yaw_rad)
    forward_y = math.sin(yaw_rad)
    return acceleration.x * forward_x + acceleration.y * forward_y


def distance_2d(loc1, loc2):
    return math.sqrt((loc1.x - loc2.x) ** 2 + (loc1.y - loc2.y) ** 2)


def angle_diff(a, b):
    diff = abs(a - b) % 360.0
    return min(diff, 360.0 - diff)


def normalize_yaw(yaw):
    return ((yaw + 180.0) % 360.0) - 180.0


def safe_delta(real_value, obs_value):
    if obs_value == "":
        return ""
    return abs(float(real_value) - float(obs_value))


def safe_angle_delta(real_value, obs_value):
    if obs_value == "":
        return ""
    return angle_diff(float(real_value), float(obs_value))


def get_lane_info(world, location):
    waypoint = world.get_map().get_waypoint(location)
    if waypoint is None:
        return -1, -1
    return waypoint.road_id, waypoint.lane_id


def get_relative_features(ego, vehicles):
    ego_loc = ego.get_location()
    ego_transform = ego.get_transform()
    ego_yaw_rad = math.radians(ego_transform.rotation.yaw)
    ego_forward_x = math.cos(ego_yaw_rad)
    ego_forward_y = math.sin(ego_yaw_rad)
    ego_speed = speed_mps(ego)

    nearest_distance = 9999.0
    nearest_relative_speed = 0.0
    front_vehicle_distance = 9999.0
    rear_vehicle_distance = 9999.0
    nearby_vehicle_count = 0

    for vehicle in vehicles:
        if vehicle.id == ego.id or not vehicle.is_alive:
            continue

        other_loc = vehicle.get_location()
        dist = distance_2d(ego_loc, other_loc)

        if dist <= NEARBY_RADIUS:
            nearby_vehicle_count += 1

        other_speed = speed_mps(vehicle)
        if dist < nearest_distance:
            nearest_distance = dist
            nearest_relative_speed = ego_speed - other_speed

        dx = other_loc.x - ego_loc.x
        dy = other_loc.y - ego_loc.y
        forward_projection = dx * ego_forward_x + dy * ego_forward_y

        if forward_projection > 0:
            front_vehicle_distance = min(front_vehicle_distance, dist)
        else:
            rear_vehicle_distance = min(rear_vehicle_distance, dist)

    return {
        "nearest_vehicle_distance": nearest_distance,
        "nearest_vehicle_relative_speed": nearest_relative_speed,
        "front_vehicle_distance": front_vehicle_distance,
        "rear_vehicle_distance": rear_vehicle_distance,
        "nearby_vehicle_count": nearby_vehicle_count,
        "traffic_density": nearby_vehicle_count / NEARBY_RADIUS,
    }


def create_real_state(ego):
    transform = ego.get_transform()
    location = transform.location
    rotation = transform.rotation

    return {
        "x": location.x,
        "y": location.y,
        "z": location.z,
        "speed": speed_mps(ego),
        "accel": longitudinal_accel_mps2(ego),
        "yaw": rotation.yaw,
    }


def create_nominal_observation(real_state):
    return {
        "x": real_state["x"] + random.gauss(0.0, 0.15),
        "y": real_state["y"] + random.gauss(0.0, 0.15),
        "z": real_state["z"] + random.gauss(0.0, 0.02),
        "speed": max(0.0, real_state["speed"] + random.gauss(0.0, 0.05)),
        "accel": real_state["accel"] + random.gauss(0.0, 0.05),
        "yaw": normalize_yaw(real_state["yaw"] + random.gauss(0.0, 0.25)),
    }


def clone_packet(packet):
    return {key: packet[key] for key in OBS_KEYS}


def default_v2_features():
    return {
        "gps_drift_magnitude": 0.0,
        "gps_drift_rate": 0.0,
        "position_jump_magnitude": 0.0,
        "position_jump_flag": 0,
        "hard_brake_flag": 0,
        "brake_intensity": 0.0,
        "deceleration_rate": 0.0,
        "time_since_brake_start": 0.0,
        "speed_spoof_ratio": 1.0,
        "speed_spoof_offset": 0.0,
        "missing_ratio": 0.0,
        "stale_packet_flag": 0,
        "packet_delay_steps": 0,
        "sensor_delay_steps": 0,
        "delayed_sensor_flag": 0,
        "heading_spoof_offset": 0.0,
        "heading_spoof_flag": 0,
    }


def compute_missing_ratio(obs_state):
    missing_count = sum(1 for key in OBS_KEYS if obs_state[key] == "")
    return missing_count / len(OBS_KEYS)


def update_window(context, tick, prefix, duration_range, cooldown_range):
    start_key = f"{prefix}_start_tick"
    end_key = f"{prefix}_end_tick"
    next_key = f"{prefix}_next_tick"

    started_now = False
    if tick >= context[next_key] and tick > context[end_key]:
        duration = random.randint(*duration_range)
        context[start_key] = tick
        context[end_key] = tick + duration - 1
        context[next_key] = context[end_key] + random.randint(*cooldown_range)
        started_now = True

    start_tick = context[start_key]
    active = start_tick is not None and start_tick <= tick <= context[end_key]
    return active, started_now


def random_unit_vector():
    angle = random.uniform(0.0, 2.0 * math.pi)
    return math.cos(angle), math.sin(angle)


def choose_dos_mode():
    population = ["normal", "partial_missing", "stale", "mixed", "full_missing"]
    weights = [0.28, 0.32, 0.19, 0.16, 0.05]
    return random.choices(population, weights=weights, k=1)[0]


def rotate_vector(x_value, y_value, angle_radians):
    cos_value = math.cos(angle_radians)
    sin_value = math.sin(angle_radians)
    return (
        x_value * cos_value - y_value * sin_value,
        x_value * sin_value + y_value * cos_value,
    )


def heading_vector(yaw_degrees):
    yaw_rad = math.radians(yaw_degrees)
    return math.cos(yaw_rad), math.sin(yaw_rad)


def lateral_vector(yaw_degrees):
    yaw_rad = math.radians(yaw_degrees)
    return -math.sin(yaw_rad), math.cos(yaw_rad)


def choose_normal_subtype(class_run_id):
    return NORMAL_SUBTYPES[class_run_id % len(NORMAL_SUBTYPES)]


def choose_gps_spoof_subtype(class_run_id):
    return GPS_SPOOF_SUBTYPES[class_run_id % len(GPS_SPOOF_SUBTYPES)]


def initialize_attack_context(attack_type, class_run_id):
    drift_dir_x, drift_dir_y = random_unit_vector()
    normal_subtype = choose_normal_subtype(class_run_id) if attack_type == "normal" else "none"
    gps_spoof_subtype = (
        choose_gps_spoof_subtype(class_run_id) if attack_type == "gps_spoofing" else "none"
    )

    return {
        "attack_type": attack_type,
        "normal_subtype": normal_subtype,
        "gps_spoof_subtype": gps_spoof_subtype,
        "real_history": deque(maxlen=64),
        "obs_history": deque(maxlen=64),
        "clean_obs_history": deque(maxlen=64),
        "gps_drift_x": 0.0,
        "gps_drift_y": 0.0,
        "gps_drift_base_step": random.uniform(0.010, 0.020),
        "gps_drift_growth": random.uniform(0.00002, 0.00008),
        "gps_drift_dir_x": drift_dir_x,
        "gps_drift_dir_y": drift_dir_y,
        "gps_curve_angle": random.uniform(-0.25, 0.25),
        "gps_heading_bias": random.choice([-1.0, 1.0]),
        "gps_map_bump_x": 0.0,
        "gps_map_bump_y": 0.0,
        "gps_map_bump_decay": 0.70,
        "gps_map_bump_next_tick": random.randint(12, 30),
        "position_jump_start_tick": None,
        "position_jump_end_tick": -1,
        "position_jump_next_tick": random.randint(10, 35),
        "position_jump_dx": 0.0,
        "position_jump_dy": 0.0,
        "position_recovery_ticks": 0,
        "brake_start_tick": None,
        "brake_end_tick": -1,
        "brake_next_tick": random.randint(8, 35),
        "lane_start_tick": None,
        "lane_end_tick": -1,
        "lane_next_tick": random.randint(8, 28),
        "lane_steer": 0.45,
        "speed_spoof_start_tick": None,
        "speed_spoof_end_tick": -1,
        "speed_spoof_next_tick": random.randint(5, 18),
        "speed_spoof_ratio": 1.0,
        "speed_spoof_offset": 0.0,
        "dos_mode": "normal",
        "dos_mode_end_tick": -1,
        "dos_mode_next_tick": 0,
        "dos_partial_keys": (),
        "dos_delay_steps": 0,
        "delay_start_tick": None,
        "delay_end_tick": -1,
        "delay_next_tick": random.randint(8, 25),
        "delay_steps": 0,
        "heading_start_tick": None,
        "heading_end_tick": -1,
        "heading_next_tick": random.randint(5, 18),
        "heading_offset": 0.0,
        "normal_brake_start_tick": None,
        "normal_brake_end_tick": -1,
        "normal_brake_next_tick": random.randint(12, 40),
        "normal_lane_start_tick": None,
        "normal_lane_end_tick": -1,
        "normal_lane_next_tick": random.randint(12, 36),
        "normal_turn_start_tick": None,
        "normal_turn_end_tick": -1,
        "normal_turn_next_tick": random.randint(16, 44),
        "normal_lane_steer": 0.0,
        "normal_turn_steer": 0.0,
        "autopilot_enabled": True,
    }


def choose_weather(world, attack_type, context):
    if attack_type == "normal":
        normal_subtype = context["normal_subtype"]
        if normal_subtype == "normal_rain":
            weather_key = random.choice(RAIN_WEATHER_KEYS)
        elif normal_subtype == "normal_night_or_low_light":
            weather_key = random.choice(LOW_LIGHT_WEATHER_KEYS)
        else:
            weather_key = random.choice(tuple(WEATHER_PRESETS))
    else:
        weather_key = random.choice(tuple(WEATHER_PRESETS))

    weather_name, weather_params = WEATHER_PRESETS[weather_key]
    world.set_weather(weather_params)
    return weather_name


def choose_npc_limit(attack_type, context):
    if attack_type == "normal" and context["normal_subtype"] == "normal_dense_traffic":
        return random.randint(32, NPC_LIMIT_RANGE[1])
    return random.randint(*NPC_LIMIT_RANGE)


def configure_ego_profile(ego, traffic_manager, attack_type, context):
    speed_diff = 0.0
    if attack_type == "normal":
        subtype = context["normal_subtype"]
        if subtype in {"normal_dense_traffic", "normal_stop_and_go"}:
            speed_diff = random.uniform(18.0, 28.0)
        elif subtype in {"normal_rain", "normal_night_or_low_light", "normal_intersection_approach"}:
            speed_diff = random.uniform(10.0, 18.0)
        elif subtype in {"normal_soft_brake", "normal_hard_brake_safe"}:
            speed_diff = random.uniform(8.0, 16.0)

    try:
        traffic_manager.vehicle_percentage_speed_difference(ego, speed_diff)
    except RuntimeError:
        pass
    except AttributeError:
        pass


def ensure_autopilot(ego, traffic_manager, context, enabled):
    if enabled and not context["autopilot_enabled"]:
        ego.set_autopilot(True, traffic_manager.get_port())
        context["autopilot_enabled"] = True
    elif not enabled and context["autopilot_enabled"]:
        ego.set_autopilot(False)
        context["autopilot_enabled"] = False


def apply_normal_controls(ego, traffic_manager, tick, context):
    subtype = context["normal_subtype"]
    if subtype in {"normal_smooth_drive", "normal_rain", "normal_night_or_low_light", "normal_dense_traffic"}:
        ensure_autopilot(ego, traffic_manager, context, True)
        return False

    if subtype in {
        "normal_stop_and_go",
        "normal_soft_brake",
        "normal_hard_brake_safe",
        "normal_intersection_approach",
    }:
        active, _ = update_window(
            context,
            tick,
            "normal_brake",
            duration_range=(12, 34),
            cooldown_range=(14, 40),
        )
        if active:
            ensure_autopilot(ego, traffic_manager, context, False)
            if subtype == "normal_stop_and_go":
                throttle = random.uniform(0.0, 0.12)
                brake = random.uniform(0.30, 0.55)
            elif subtype == "normal_soft_brake":
                throttle = random.uniform(0.05, 0.18)
                brake = random.uniform(0.18, 0.36)
            elif subtype == "normal_hard_brake_safe":
                throttle = random.uniform(0.0, 0.10)
                brake = random.uniform(0.45, 0.72)
            else:
                throttle = random.uniform(0.02, 0.16)
                brake = random.uniform(0.20, 0.42)

            ego.apply_control(
                carla.VehicleControl(
                    throttle=throttle,
                    brake=brake,
                    steer=random.uniform(-0.04, 0.04),
                )
            )
            return True

    if subtype == "normal_lane_change_safe":
        active, started_now = update_window(
            context,
            tick,
            "normal_lane",
            duration_range=(16, 28),
            cooldown_range=(18, 36),
        )
        if active:
            ensure_autopilot(ego, traffic_manager, context, False)
            if started_now:
                direction = random.choice([-1.0, 1.0])
                context["normal_lane_steer"] = direction * random.uniform(0.18, 0.28)

            ego.apply_control(
                carla.VehicleControl(
                    throttle=random.uniform(0.25, 0.40),
                    brake=0.0,
                    steer=context["normal_lane_steer"] + random.uniform(-0.02, 0.02),
                )
            )
            return True

    if subtype == "normal_turning":
        active, started_now = update_window(
            context,
            tick,
            "normal_turn",
            duration_range=(20, 34),
            cooldown_range=(18, 42),
        )
        if active:
            ensure_autopilot(ego, traffic_manager, context, False)
            if started_now:
                direction = random.choice([-1.0, 1.0])
                context["normal_turn_steer"] = direction * random.uniform(0.22, 0.38)

            ego.apply_control(
                carla.VehicleControl(
                    throttle=random.uniform(0.18, 0.32),
                    brake=0.0,
                    steer=context["normal_turn_steer"] + random.uniform(-0.03, 0.03),
                )
            )
            return True

    ensure_autopilot(ego, traffic_manager, context, True)
    return False


def apply_attack_controls(ego, traffic_manager, attack_type, tick, context):
    if attack_type == "normal":
        handled = apply_normal_controls(ego, traffic_manager, tick, context)
        if not handled:
            ensure_autopilot(ego, traffic_manager, context, True)
        return

    if attack_type == "sudden_brake":
        active, started_now = update_window(
            context,
            tick,
            "brake",
            duration_range=(16, 30),
            cooldown_range=(18, 45),
        )
        if active:
            ensure_autopilot(ego, traffic_manager, context, False)
            if started_now:
                context["brake_start_tick"] = tick
            ego.apply_control(
                carla.VehicleControl(
                    throttle=0.0,
                    brake=1.0,
                    steer=random.uniform(-0.03, 0.03),
                )
            )
            return

    if attack_type == "lane_deviation":
        active, started_now = update_window(
            context,
            tick,
            "lane",
            duration_range=(18, 36),
            cooldown_range=(18, 40),
        )
        if active:
            ensure_autopilot(ego, traffic_manager, context, False)
            if started_now:
                direction = random.choice([-1.0, 1.0])
                magnitude = random.uniform(0.35, 0.60)
                context["lane_steer"] = direction * magnitude
            ego.apply_control(
                carla.VehicleControl(
                    throttle=0.35,
                    brake=0.0,
                    steer=context["lane_steer"] + random.uniform(-0.04, 0.04),
                )
            )
            return

    ensure_autopilot(ego, traffic_manager, context, True)


def apply_gps_spoofing(obs_state, real_state, tick, context, features):
    subtype = context["gps_spoof_subtype"]
    base_step = context["gps_drift_base_step"] + tick * context["gps_drift_growth"]
    step_size = min(0.09, max(0.008, base_step + random.uniform(-0.0015, 0.0015)))

    heading_x, heading_y = heading_vector(real_state["yaw"])
    lateral_x, lateral_y = lateral_vector(real_state["yaw"])
    drift_x = context["gps_drift_x"]
    drift_y = context["gps_drift_y"]
    yaw_offset = 0.0
    speed_bias = 0.0

    if subtype == "gps_slow_drift":
        drift_x += context["gps_drift_dir_x"] * step_size + random.gauss(0.0, 0.01)
        drift_y += context["gps_drift_dir_y"] * step_size + random.gauss(0.0, 0.01)
        yaw_offset = random.uniform(-2.0, 2.0)
    elif subtype == "gps_directional_drift":
        drift_x += heading_x * step_size * 1.35 + random.gauss(0.0, 0.02)
        drift_y += heading_y * step_size * 1.35 + random.gauss(0.0, 0.02)
        yaw_offset = context["gps_heading_bias"] * random.uniform(4.0, 10.0)
        speed_bias = random.uniform(-0.2, 0.4)
    elif subtype == "gps_curved_drift":
        context["gps_curve_angle"] += random.uniform(0.03, 0.08) * context["gps_heading_bias"]
        curve_x, curve_y = rotate_vector(context["gps_drift_dir_x"], context["gps_drift_dir_y"], context["gps_curve_angle"])
        drift_x += curve_x * step_size * 1.20 + random.gauss(0.0, 0.03)
        drift_y += curve_y * step_size * 1.20 + random.gauss(0.0, 0.03)
        yaw_offset = normalize_yaw(math.degrees(context["gps_curve_angle"])) * 0.30
        speed_bias = random.uniform(-0.4, 0.6)
    elif subtype == "gps_lane_inconsistent_drift":
        drift_x += (lateral_x * 1.70 + heading_x * 0.20) * step_size + random.gauss(0.0, 0.03)
        drift_y += (lateral_y * 1.70 + heading_y * 0.20) * step_size + random.gauss(0.0, 0.03)
        yaw_offset = context["gps_heading_bias"] * random.uniform(8.0, 18.0)
        speed_bias = random.uniform(-0.6, 0.9)
    elif subtype == "gps_map_inconsistent_drift":
        drift_x += (heading_x * 0.85 + lateral_x * 1.10) * step_size + random.gauss(0.0, 0.04)
        drift_y += (heading_y * 0.85 + lateral_y * 1.10) * step_size + random.gauss(0.0, 0.04)
        if tick >= context["gps_map_bump_next_tick"]:
            bump_distance = random.uniform(6.0, 14.0)
            bump_dir_x, bump_dir_y = random_unit_vector()
            context["gps_map_bump_x"] = bump_dir_x * bump_distance
            context["gps_map_bump_y"] = bump_dir_y * bump_distance
            context["gps_map_bump_next_tick"] = tick + random.randint(16, 34)
        context["gps_map_bump_x"] *= context["gps_map_bump_decay"]
        context["gps_map_bump_y"] *= context["gps_map_bump_decay"]
        yaw_offset = context["gps_heading_bias"] * random.uniform(12.0, 24.0)
        speed_bias = random.uniform(-0.8, 1.2)

    context["gps_drift_x"] = drift_x
    context["gps_drift_y"] = drift_y

    total_x = drift_x + context["gps_map_bump_x"]
    total_y = drift_y + context["gps_map_bump_y"]

    obs_state["x"] += total_x + random.gauss(0.0, 0.25)
    obs_state["y"] += total_y + random.gauss(0.0, 0.25)
    obs_state["speed"] = max(0.0, obs_state["speed"] + speed_bias + random.gauss(0.0, 0.12))
    obs_state["yaw"] = normalize_yaw(obs_state["yaw"] + yaw_offset + random.gauss(0.0, 0.8))

    features["gps_drift_magnitude"] = math.sqrt(total_x ** 2 + total_y ** 2)
    features["gps_drift_rate"] = max(0.0, step_size * FPS)


def apply_position_spoofing(obs_state, tick, context, features):
    active, started_now = update_window(
        context,
        tick,
        "position_jump",
        duration_range=(8, 18),
        cooldown_range=(10, 34),
    )

    if started_now:
        jump_distance = random.uniform(30.0, 80.0)
        dir_x, dir_y = random_unit_vector()
        context["position_jump_dx"] = dir_x * jump_distance
        context["position_jump_dy"] = dir_y * jump_distance
        context["position_recovery_ticks"] = random.randint(4, 10)

    if active:
        obs_state["x"] += context["position_jump_dx"] + random.gauss(0.0, 0.8)
        obs_state["y"] += context["position_jump_dy"] + random.gauss(0.0, 0.8)
        features["position_jump_flag"] = 1
    elif context["position_recovery_ticks"] > 0:
        context["position_jump_dx"] *= 0.55
        context["position_jump_dy"] *= 0.55
        context["position_recovery_ticks"] -= 1
        obs_state["x"] += context["position_jump_dx"] + random.gauss(0.0, 0.4)
        obs_state["y"] += context["position_jump_dy"] + random.gauss(0.0, 0.4)

    features["position_jump_magnitude"] = math.sqrt(
        context["position_jump_dx"] ** 2 + context["position_jump_dy"] ** 2
    )


def apply_speed_spoofing(obs_state, tick, context, features):
    active, started_now = update_window(
        context,
        tick,
        "speed_spoof",
        duration_range=(24, 60),
        cooldown_range=(10, 24),
    )

    if started_now:
        mode = random.choice(["underestimate", "overestimate"])
        if mode == "underestimate":
            context["speed_spoof_ratio"] = random.uniform(0.35, 0.75)
            context["speed_spoof_offset"] = random.uniform(-3.0, -0.5)
        else:
            context["speed_spoof_ratio"] = random.uniform(1.25, 2.10)
            context["speed_spoof_offset"] = random.uniform(1.0, 7.0)

    if active:
        ratio = context["speed_spoof_ratio"]
        offset = context["speed_spoof_offset"]
        obs_state["speed"] = max(0.0, obs_state["speed"] * ratio + offset + random.gauss(0.0, 0.2))
        features["speed_spoof_ratio"] = ratio
        features["speed_spoof_offset"] = offset


def apply_sensor_noise(obs_state):
    obs_state["x"] += random.gauss(0.0, 6.0)
    obs_state["y"] += random.gauss(0.0, 6.0)
    obs_state["z"] += random.gauss(0.0, 0.05)
    obs_state["speed"] = max(0.0, obs_state["speed"] + random.gauss(0.0, 3.0))
    obs_state["accel"] += random.gauss(0.0, 1.5)
    obs_state["yaw"] = normalize_yaw(obs_state["yaw"] + random.gauss(0.0, 10.0))


def apply_dos(obs_state, tick, context, features):
    if tick >= context["dos_mode_next_tick"] or tick > context["dos_mode_end_tick"]:
        duration = random.randint(4, 14)
        context["dos_mode"] = choose_dos_mode()
        context["dos_mode_end_tick"] = tick + duration - 1
        context["dos_mode_next_tick"] = context["dos_mode_end_tick"] + random.randint(1, 6)
        context["dos_partial_keys"] = tuple(random.sample(OBS_KEYS, random.randint(1, 3)))
        context["dos_delay_steps"] = random.randint(1, 6)

    mode = context["dos_mode"]

    if mode in {"stale", "mixed"} and context["clean_obs_history"]:
        max_delay = min(context["dos_delay_steps"], len(context["clean_obs_history"]))
        delay_steps = max(1, max_delay)
        stale_source = clone_packet(context["clean_obs_history"][-delay_steps])
        for key in OBS_KEYS:
            obs_state[key] = stale_source[key]
        features["stale_packet_flag"] = 1
        features["packet_delay_steps"] = delay_steps

    if mode == "partial_missing":
        for key in context["dos_partial_keys"]:
            obs_state[key] = ""
    elif mode == "mixed":
        for key in random.sample(OBS_KEYS, random.randint(1, 2)):
            obs_state[key] = ""
    elif mode == "full_missing":
        for key in OBS_KEYS:
            obs_state[key] = ""


def apply_delayed_sensor_attack(obs_state, context, tick, features):
    active, started_now = update_window(
        context,
        tick,
        "delay",
        duration_range=(20, 52),
        cooldown_range=(10, 26),
    )

    if started_now:
        context["delay_steps"] = random.randint(2, 12)

    if active and len(context["real_history"]) > context["delay_steps"]:
        delayed_state = context["real_history"][-(context["delay_steps"] + 1)]
        obs_state["x"] = delayed_state["x"] + random.gauss(0.0, 0.20)
        obs_state["y"] = delayed_state["y"] + random.gauss(0.0, 0.20)
        obs_state["speed"] = max(0.0, delayed_state["speed"] + random.gauss(0.0, 0.08))
        obs_state["accel"] = delayed_state["accel"] + random.gauss(0.0, 0.08)
        obs_state["yaw"] = normalize_yaw(delayed_state["yaw"] + random.gauss(0.0, 0.4))
        features["sensor_delay_steps"] = context["delay_steps"]
        features["delayed_sensor_flag"] = 1


def apply_heading_spoofing(obs_state, tick, context, features):
    active, started_now = update_window(
        context,
        tick,
        "heading",
        duration_range=(18, 46),
        cooldown_range=(12, 28),
    )

    if started_now:
        sign = random.choice([-1.0, 1.0])
        context["heading_offset"] = sign * random.uniform(45.0, 120.0)

    if active:
        effective_offset = context["heading_offset"] + random.gauss(0.0, 3.0)
        obs_state["yaw"] = normalize_yaw(obs_state["yaw"] + effective_offset)
        features["heading_spoof_offset"] = effective_offset
        features["heading_spoof_flag"] = 1


def create_observed_state(attack_type, tick, real_state, context):
    obs_state = create_nominal_observation(real_state)
    features = default_v2_features()

    if attack_type == "gps_spoofing":
        apply_gps_spoofing(obs_state, real_state, tick, context, features)
    elif attack_type == "position_spoofing":
        apply_position_spoofing(obs_state, tick, context, features)
    elif attack_type == "speed_spoofing":
        apply_speed_spoofing(obs_state, tick, context, features)
    elif attack_type == "sensor_noise":
        apply_sensor_noise(obs_state)
    elif attack_type == "dos":
        apply_dos(obs_state, tick, context, features)
    elif attack_type == "delayed_sensor_attack":
        apply_delayed_sensor_attack(obs_state, context, tick, features)
    elif attack_type == "heading_spoofing":
        apply_heading_spoofing(obs_state, tick, context, features)

    features["missing_ratio"] = compute_missing_ratio(obs_state)
    return obs_state, features


def update_observation_history(context, obs_state, features):
    context["obs_history"].append(clone_packet(obs_state))
    if features["missing_ratio"] == 0.0:
        context["clean_obs_history"].append(clone_packet(obs_state))


def spawn_traffic(world, traffic_manager, npc_limit):
    blueprint_library = world.get_blueprint_library()
    vehicle_blueprints = blueprint_library.filter("vehicle.*")
    if not vehicle_blueprints:
        raise RuntimeError("No vehicle blueprints were found.")

    spawn_points = world.get_map().get_spawn_points()
    if not spawn_points:
        raise RuntimeError("No spawn points were found on the map.")

    random.shuffle(spawn_points)

    ego_candidates = blueprint_library.filter("vehicle.tesla.model3")
    ego_blueprint = ego_candidates[0] if ego_candidates else random.choice(vehicle_blueprints)
    if ego_blueprint.has_attribute("role_name"):
        ego_blueprint.set_attribute("role_name", "hero")

    ego = None
    used_spawn_index = None
    for index, spawn_point in enumerate(spawn_points):
        ego = world.try_spawn_actor(ego_blueprint, spawn_point)
        if ego is not None:
            used_spawn_index = index
            break

    if ego is None:
        raise RuntimeError("Failed to spawn the ego vehicle.")

    ego.set_autopilot(True, traffic_manager.get_port())
    vehicles = [ego]

    for index, spawn_point in enumerate(spawn_points):
        if index == used_spawn_index or len(vehicles) - 1 >= npc_limit:
            continue

        npc_blueprint = random.choice(vehicle_blueprints)
        if npc_blueprint.has_attribute("color"):
            color = random.choice(npc_blueprint.get_attribute("color").recommended_values)
            npc_blueprint.set_attribute("color", color)

        npc = world.try_spawn_actor(npc_blueprint, spawn_point)
        if npc is None:
            continue

        npc.set_autopilot(True, traffic_manager.get_port())
        vehicles.append(npc)

    return ego, vehicles


def warm_up(world, ego, traffic_manager):
    ego.set_autopilot(True, traffic_manager.get_port())
    for _ in range(WARMUP_TICKS):
        world.tick()


def destroy_vehicles(world, vehicles):
    for vehicle in reversed(vehicles):
        try:
            if vehicle.is_alive:
                vehicle.destroy()
        except RuntimeError:
            pass

    if world is not None and vehicles:
        try:
            world.tick()
        except RuntimeError:
            pass


def cleanup(world, original_settings, traffic_manager):
    if traffic_manager is not None:
        try:
            traffic_manager.set_synchronous_mode(False)
        except RuntimeError:
            pass

    if world is not None and original_settings is not None:
        try:
            world.apply_settings(original_settings)
        except RuntimeError:
            pass


def build_row(
    snapshot,
    scenario_id,
    run_id,
    attack_run_id,
    class_run_id,
    tick_in_run,
    ego,
    attack_type,
    real_state,
    obs_state,
    world,
    vehicles,
    previous_real_state,
    features,
    context,
    weather_preset,
):
    control = ego.get_control()

    if previous_real_state["speed"] is None:
        speed_change_rate = 0.0
        acceleration_change_rate = 0.0
        yaw_change_rate = 0.0
        position_jump = 0.0
    else:
        speed_change_rate = real_state["speed"] - previous_real_state["speed"]
        acceleration_change_rate = real_state["accel"] - previous_real_state["accel"]
        yaw_change_rate = angle_diff(real_state["yaw"], previous_real_state["yaw"])
        position_jump = math.sqrt(
            (real_state["x"] - previous_real_state["x"]) ** 2
            + (real_state["y"] - previous_real_state["y"]) ** 2
        )

    previous_real_state["speed"] = real_state["speed"]
    previous_real_state["accel"] = real_state["accel"]
    previous_real_state["yaw"] = real_state["yaw"]
    previous_real_state["x"] = real_state["x"]
    previous_real_state["y"] = real_state["y"]

    try:
        location = ego.get_transform().location
        road_id, lane_id = get_lane_info(world, location)
    except RuntimeError:
        road_id, lane_id = -1, -1

    relative_features = get_relative_features(ego, vehicles)

    brake_active = (
        attack_type == "sudden_brake"
        and context["brake_start_tick"] is not None
        and context["brake_start_tick"] <= tick_in_run <= context["brake_end_tick"]
    )
    if brake_active:
        features["hard_brake_flag"] = 1
        features["time_since_brake_start"] = (tick_in_run - context["brake_start_tick"]) / FPS

    features["brake_intensity"] = float(control.brake)
    features["deceleration_rate"] = max(0.0, -speed_change_rate * FPS)

    missing_ratio = features["missing_ratio"]
    is_missing = int(missing_ratio > 0.0)

    row = {
        "timestamp": time.time(),
        "frame": snapshot.frame,
        "scenario_id": scenario_id,
        "run_id": run_id,
        "attack_run_id": attack_run_id,
        "class_run_id": class_run_id,
        "tick_in_run": tick_in_run,
        "vehicle_id": ego.id,
        "map_name": world.get_map().name,
        "weather_preset": weather_preset,
        "npc_vehicle_count": max(0, len(vehicles) - 1),
        "attack_type": attack_type,
        "normal_subtype": context["normal_subtype"],
        "gps_spoof_subtype": context["gps_spoof_subtype"],
        "binary_label": 0 if attack_type == "normal" else 1,
        "multiclass_label": CLASS_MAP[attack_type],
        "real_x": real_state["x"],
        "real_y": real_state["y"],
        "real_z": real_state["z"],
        "real_speed": real_state["speed"],
        "real_accel": real_state["accel"],
        "real_yaw": real_state["yaw"],
        "obs_x": obs_state["x"],
        "obs_y": obs_state["y"],
        "obs_z": obs_state["z"],
        "obs_speed": obs_state["speed"],
        "obs_accel": obs_state["accel"],
        "obs_yaw": obs_state["yaw"],
        "road_id": road_id,
        "lane_id": lane_id,
        "throttle": control.throttle,
        "brake": control.brake,
        "steer": control.steer,
        "delta_pos_x": safe_delta(real_state["x"], obs_state["x"]),
        "delta_pos_y": safe_delta(real_state["y"], obs_state["y"]),
        "delta_speed": safe_delta(real_state["speed"], obs_state["speed"]),
        "delta_accel": safe_delta(real_state["accel"], obs_state["accel"]),
        "yaw_error": safe_angle_delta(real_state["yaw"], obs_state["yaw"]),
        "is_missing": is_missing,
        "nearest_vehicle_distance": relative_features["nearest_vehicle_distance"],
        "nearest_vehicle_relative_speed": relative_features["nearest_vehicle_relative_speed"],
        "front_vehicle_distance": relative_features["front_vehicle_distance"],
        "rear_vehicle_distance": relative_features["rear_vehicle_distance"],
        "nearby_vehicle_count": relative_features["nearby_vehicle_count"],
        "traffic_density": relative_features["traffic_density"],
        "speed_change_rate": speed_change_rate,
        "acceleration_change_rate": acceleration_change_rate,
        "yaw_change_rate": yaw_change_rate,
        "position_jump": position_jump,
    }

    row.update(features)
    return row


def collect_single_run_rows(
    writer,
    csv_file,
    world,
    traffic_manager,
    attack_type,
    class_run_id,
    global_run_id,
):
    attack_run_id = f"{attack_type}_run_{class_run_id:02d}"
    vehicles = []
    run_rows = []

    try:
        context = initialize_attack_context(attack_type, class_run_id)
        weather_preset = choose_weather(world, attack_type, context)
        npc_limit = choose_npc_limit(attack_type, context)
        ego, vehicles = spawn_traffic(world, traffic_manager, npc_limit)
        configure_ego_profile(ego, traffic_manager, attack_type, context)
        warm_up(world, ego, traffic_manager)

        previous_real_state = {
            "speed": None,
            "accel": None,
            "yaw": None,
            "x": None,
            "y": None,
        }

        for tick_in_run in range(TICKS_PER_RUN):
            apply_attack_controls(ego, traffic_manager, attack_type, tick_in_run, context)

            world.tick()
            snapshot = world.get_snapshot()

            if not ego.is_alive:
                raise RuntimeError("Ego vehicle was destroyed during collection.")

            real_state = create_real_state(ego)
            context["real_history"].append(real_state.copy())

            obs_state, features = create_observed_state(
                attack_type,
                tick_in_run,
                real_state,
                context,
            )

            row = build_row(
                snapshot,
                scenario_id=global_run_id,
                run_id=global_run_id,
                attack_run_id=attack_run_id,
                class_run_id=class_run_id,
                tick_in_run=tick_in_run,
                ego=ego,
                attack_type=attack_type,
                real_state=real_state,
                obs_state=obs_state,
                world=world,
                vehicles=vehicles,
                previous_real_state=previous_real_state,
                features=features,
                context=context,
                weather_preset=weather_preset,
            )
            run_rows.append(row)
            update_observation_history(context, obs_state, features)

        if ego.is_alive:
            ego.set_autopilot(True, traffic_manager.get_port())
        writer.writerows(run_rows)
        csv_file.flush()
        return TICKS_PER_RUN

    finally:
        destroy_vehicles(world, vehicles)


def collect_attack_rows(writer, csv_file, world, traffic_manager):
    global_run_id = 0
    run_plan = build_run_plan()

    for attack_type in ATTACK_TYPES:
        runs_for_class = run_plan[attack_type]
        class_rows_written = 0
        print(f"\n[INFO] Collecting V6 class: {attack_type} ({runs_for_class} runs)")

        for class_run_id in range(runs_for_class):
            run_label = f"{attack_type} run {class_run_id + 1}/{runs_for_class}"

            for attempt in range(1, MAX_RUN_RETRIES + 1):
                global_run_id += 1
                try:
                    written = collect_single_run_rows(
                        writer,
                        csv_file,
                        world,
                        traffic_manager,
                        attack_type,
                        class_run_id,
                        global_run_id,
                    )
                    class_rows_written += written
                    print(
                        f"[INFO] {run_label} completed "
                        f"({class_rows_written}/{runs_for_class * TICKS_PER_RUN} samples)"
                    )
                    break
                except KeyboardInterrupt:
                    raise
                except Exception as exc:
                    csv_file.flush()
                    print(f"[WARN] {run_label} attempt {attempt}/{MAX_RUN_RETRIES} failed: {exc}")
                    traceback.print_exc()
                    if attempt == MAX_RUN_RETRIES:
                        raise RuntimeError(
                            f"{run_label} failed after {MAX_RUN_RETRIES} attempts."
                        ) from exc

        print(f"[OK] {attack_type} completed with {class_rows_written} rows.")


def main():
    client = carla.Client(HOST, PORT)
    client.set_timeout(TIMEOUT)

    world = None
    original_settings = None
    traffic_manager = None
    run_plan = build_run_plan()
    total_runs = sum(run_plan.values())
    total_attack_runs = sum(run_plan[attack_type] for attack_type in ATTACK_ONLY_TYPES)

    try:
        print(f"[INFO] Output file: {OUTPUT_FILE}")
        print(f"[INFO] Attack runs per attack label: {RUNS_PER_ATTACK_CLASS}")
        print(f"[INFO] Normal runs: {run_plan['normal']}")
        print(f"[INFO] Total attack runs: {total_attack_runs}")
        print(f"[INFO] Ticks per run: {TICKS_PER_RUN}")
        print(f"[INFO] Expected normal rows: {run_plan['normal'] * TICKS_PER_RUN}")
        print(f"[INFO] Expected attack rows: {total_attack_runs * TICKS_PER_RUN}")
        print(f"[INFO] Expected total rows: {total_runs * TICKS_PER_RUN}")

        world = client.get_world()
        original_settings = world.get_settings()

        settings = world.get_settings()
        settings.synchronous_mode = True
        settings.fixed_delta_seconds = 1.0 / FPS
        world.apply_settings(settings)

        traffic_manager = client.get_trafficmanager()
        traffic_manager.set_synchronous_mode(True)
        traffic_manager.set_global_distance_to_leading_vehicle(2.5)

        with OUTPUT_FILE.open("w", newline="", encoding="utf-8") as csv_file:
            writer = csv.DictWriter(csv_file, fieldnames=FIELDNAMES)
            writer.writeheader()
            collect_attack_rows(writer, csv_file, world, traffic_manager)

        print(f"\n[DONE] V6 raw data saved: {OUTPUT_FILE}")

    finally:
        print("[INFO] Cleaning up CARLA settings...")
        cleanup(world, original_settings, traffic_manager)
        print("[DONE] CARLA cleanup finished.")


if __name__ == "__main__":
    main()
