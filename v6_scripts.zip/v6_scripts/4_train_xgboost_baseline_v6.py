from datetime import datetime
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import (
    ConfusionMatrixDisplay,
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    confusion_matrix,
)
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier


TASK_TYPE = "binary"  # "multiclass" or "binary"
FEATURE_SET = "behavior_only"  # "full" or "behavior_only"

def resolve_v6_root() -> Path:
    script_path = Path(__file__).resolve()
    for parent in [script_path.parent, *script_path.parents]:
        if parent.name == "v6":
            return parent
    for parent in script_path.parents:
        candidate = parent / "v6"
        if candidate.exists():
            return candidate
    return script_path.parent / "v6"

V6_ROOT = resolve_v6_root()


def resolve_default_dataset_dir() -> Path:
    return V6_ROOT / "datasets" / "carla_tabular_dataset_v6"


DATASET_DIR = resolve_default_dataset_dir()
RESULTS_ROOT = V6_ROOT / "results" / "xgboost_v6"

CLASS_MAP = {
    "normal": 0,
    "gps_spoofing": 1,
    "position_spoofing": 2,
    "speed_spoofing": 3,
    "sudden_brake": 4,
    "lane_deviation": 5,
    "sensor_noise": 6,
    "dos": 7,
    "delayed_sensor_attack": 8,
    "heading_spoofing": 9,
}

CLASS_NAME_BY_ID = {value: key for key, value in CLASS_MAP.items()}
GROUP_COLUMN_CANDIDATES = ("attack_run_id", "run_id", "scenario_id")

BEHAVIOR_ONLY_FEATURES = [
    "obs_x",
    "obs_y",
    "obs_z",
    "obs_speed",
    "obs_accel",
    "obs_yaw",
    "road_id",
    "lane_id",
    "throttle",
    "brake",
    "steer",
    "delta_pos_x",
    "delta_pos_y",
    "delta_speed",
    "delta_accel",
    "yaw_error",
    "is_missing",
    "nearest_vehicle_distance",
    "nearest_vehicle_relative_speed",
    "front_vehicle_distance",
    "rear_vehicle_distance",
    "nearby_vehicle_count",
    "traffic_density",
    "speed_change_rate",
    "acceleration_change_rate",
    "yaw_change_rate",
    "position_jump",
]

FULL_FEATURES = BEHAVIOR_ONLY_FEATURES + [
    "gps_drift_magnitude",
    "gps_drift_rate",
    "position_jump_magnitude",
    "position_jump_flag",
    "hard_brake_flag",
    "brake_intensity",
    "deceleration_rate",
    "time_since_brake_start",
    "speed_spoof_ratio",
    "speed_spoof_offset",
    "missing_ratio",
    "stale_packet_flag",
    "packet_delay_steps",
    "sensor_delay_steps",
    "delayed_sensor_flag",
    "heading_spoof_offset",
    "heading_spoof_flag",
]

LEAKAGE_LIKE_FEATURES = [
    "heading_spoof_flag",
    "gps_drift_magnitude",
    "gps_drift_rate",
    "position_jump_magnitude",
    "position_jump_flag",
    "hard_brake_flag",
    "speed_spoof_ratio",
    "missing_ratio",
    "stale_packet_flag",
    "packet_delay_steps",
    "sensor_delay_steps",
    "delayed_sensor_flag",
    "heading_spoof_offset",
]

FORBIDDEN_COLUMNS = {
    "attack_type",
    "normal_subtype",
    "gps_spoof_subtype",
    "binary_label",
    "multiclass_label",
    "attack_run_id",
    "scenario_id",
    "run_id",
    "class_run_id",
    "vehicle_id",
    "timestamp",
    "frame",
    "map_name",
    "weather_preset",
}

EARLY_STOPPING_ROUNDS = 30
RANDOM_STATE = 42
BALANCE_BINARY_NORMAL_TO_ATTACK = True
BALANCE_MULTICLASS_SPLITS = True


def make_run_dir():
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = RESULTS_ROOT / f"{TASK_TYPE}_{FEATURE_SET}_{timestamp}"
    run_dir.mkdir(parents=True, exist_ok=True)
    return run_dir


def load_split(split_name):
    split_dir = DATASET_DIR / split_name
    combined_file = split_dir / f"{split_name}_combined.csv"

    if combined_file.exists():
        return pd.read_csv(combined_file, low_memory=False)

    files = sorted(split_dir.glob("*/data.csv"))
    dfs = [pd.read_csv(file, low_memory=False) for file in files]
    if not dfs:
        raise RuntimeError(f"No split files found for: {split_name}")
    return pd.concat(dfs, ignore_index=True)


def resolve_group_column(df):
    for column_name in GROUP_COLUMN_CANDIDATES:
        if column_name in df.columns:
            return column_name
    return None


def attach_row_index(df):
    df = df.reset_index(drop=True).copy()
    df["window_start_index"] = np.arange(len(df), dtype=int)
    df["window_end_index"] = df["window_start_index"]
    return df


def ensure_group_disjoint(train_df, val_df, test_df):
    sample_df = train_df if not train_df.empty else val_df
    group_column = resolve_group_column(sample_df)
    if group_column is None:
        print("[WARN] No run/group column found; split leakage guard skipped.")
        return None

    train_groups = set(train_df[group_column].dropna().astype(str))
    val_groups = set(val_df[group_column].dropna().astype(str))
    test_groups = set(test_df[group_column].dropna().astype(str))

    overlaps = {
        "train_val": train_groups & val_groups,
        "train_test": train_groups & test_groups,
        "val_test": val_groups & test_groups,
    }

    overlap_messages = []
    for overlap_name, overlap_values in overlaps.items():
        if overlap_values:
            preview = ", ".join(sorted(overlap_values)[:10])
            overlap_messages.append(f"{overlap_name}: {preview}")

    if overlap_messages:
        raise RuntimeError("Run leakage detected across splits -> " + " | ".join(overlap_messages))

    print(f"[INFO] Leakage guard passed with group column: {group_column}")
    return group_column


def get_task_config():
    if TASK_TYPE == "binary":
        return {
            "target_column": "binary_label",
            "objective": "binary:logistic",
            "eval_metric": "logloss",
            "labels": [0, 1],
            "target_names": ["normal", "attack"],
            "num_class": None,
        }

    if TASK_TYPE == "multiclass":
        labels = sorted(CLASS_NAME_BY_ID.keys())
        return {
            "target_column": "multiclass_label",
            "objective": "multi:softmax",
            "eval_metric": "mlogloss",
            "labels": labels,
            "target_names": [CLASS_NAME_BY_ID[label] for label in labels],
            "num_class": len(labels),
        }

    raise ValueError(f"Unsupported TASK_TYPE: {TASK_TYPE}")


def get_feature_candidates():
    if FEATURE_SET == "full":
        return FULL_FEATURES
    if FEATURE_SET == "behavior_only":
        return BEHAVIOR_ONLY_FEATURES
    raise ValueError(f"Unsupported FEATURE_SET: {FEATURE_SET}")


def resolve_feature_columns(train_df, val_df, test_df, target_column):
    feature_candidates = get_feature_candidates()
    common_columns = set(train_df.columns) & set(val_df.columns) & set(test_df.columns)
    forbidden_columns = set(FORBIDDEN_COLUMNS)
    forbidden_columns.add(target_column)

    selected_features = []
    skipped_features = []

    for feature_name in feature_candidates:
        if feature_name in forbidden_columns:
            skipped_features.append(feature_name)
        elif feature_name in common_columns:
            selected_features.append(feature_name)
        else:
            skipped_features.append(feature_name)

    if skipped_features:
        print(f"[WARN] Missing or forbidden selected features skipped: {', '.join(skipped_features)}")

    if not selected_features:
        raise RuntimeError("No usable features remain after feature selection.")

    return selected_features, skipped_features


def allocate_sample_counts(group_sizes, target_total):
    if target_total <= 0:
        return {group_name: 0 for group_name in group_sizes}

    total_rows = sum(group_sizes.values())
    if target_total >= total_rows:
        return dict(group_sizes)

    raw_counts = {
        group_name: target_total * group_size / total_rows
        for group_name, group_size in group_sizes.items()
    }
    counts = {
        group_name: int(np.floor(raw_count))
        for group_name, raw_count in raw_counts.items()
    }

    if target_total >= len(group_sizes):
        zero_groups = [group_name for group_name, count in counts.items() if count == 0]
        for group_name in zero_groups:
            donor = max(counts, key=lambda item: counts[item])
            if counts[donor] > 1:
                counts[donor] -= 1
                counts[group_name] += 1

    remainder = target_total - sum(counts.values())
    if remainder > 0:
        fractional_order = sorted(
            group_sizes,
            key=lambda group_name: raw_counts[group_name] - counts[group_name],
            reverse=True,
        )
        for group_name in fractional_order:
            if remainder == 0:
                break
            if counts[group_name] < group_sizes[group_name]:
                counts[group_name] += 1
                remainder -= 1

    return counts


def sample_rows(df, target_total, random_state, stratify_column=None):
    if target_total >= len(df):
        return df.copy()

    if not stratify_column or stratify_column not in df.columns:
        return df.sample(n=target_total, random_state=random_state).copy()

    group_sizes = df.groupby(stratify_column).size().to_dict()
    sample_counts = allocate_sample_counts(group_sizes, target_total)

    sampled_frames = []
    for group_name, group_df in df.groupby(stratify_column, sort=True):
        sample_count = sample_counts.get(group_name, 0)
        if sample_count <= 0:
            continue
        sampled_frames.append(group_df.sample(n=sample_count, random_state=random_state).copy())

    if not sampled_frames:
        raise RuntimeError("Sampling failed; no rows selected.")

    sampled_df = pd.concat(sampled_frames, ignore_index=True)
    return sampled_df.sample(frac=1.0, random_state=random_state).reset_index(drop=True)


def get_normal_stratify_column(df):
    if "normal_subtype" in df.columns:
        return "normal_subtype"
    return None


def get_attack_stratify_column(df):
    if "attack_type" in df.columns:
        return "attack_type"
    return None


def get_multiclass_stratify_column(df, label_value):
    if label_value == CLASS_MAP["normal"] and "normal_subtype" in df.columns:
        return "normal_subtype"
    if label_value == CLASS_MAP["gps_spoofing"] and "gps_spoof_subtype" in df.columns:
        return "gps_spoof_subtype"
    return None


def balance_binary_split(df, split_name):
    normal_df = df[df["binary_label"] == 0].copy()
    attack_df = df[df["binary_label"] == 1].copy()

    if normal_df.empty or attack_df.empty:
        raise RuntimeError(f"Cannot balance binary split {split_name}: one class is empty.")

    target_count = min(len(normal_df), len(attack_df))
    split_seed = RANDOM_STATE + sum(ord(ch) for ch in split_name)

    balanced_normal_df = sample_rows(
        normal_df,
        target_count,
        split_seed,
        stratify_column=get_normal_stratify_column(normal_df),
    )
    balanced_attack_df = attack_df.copy()

    balanced_df = pd.concat([balanced_normal_df, balanced_attack_df], ignore_index=True)
    balanced_df = balanced_df.sample(frac=1.0, random_state=split_seed + 2).reset_index(drop=True)

    info = {
        "before_normal": len(normal_df),
        "before_attack": len(attack_df),
        "after_normal": len(balanced_normal_df),
        "after_attack": len(balanced_attack_df),
        "rule": "normal<=attack",
    }
    return balanced_df, info


def balance_multiclass_split(df, split_name, target_column):
    label_counts = df[target_column].value_counts().sort_index().to_dict()
    if not label_counts:
        raise RuntimeError(f"Cannot balance multiclass split {split_name}: split is empty.")

    target_count = min(label_counts.values())
    split_seed = RANDOM_STATE + sum(ord(ch) for ch in split_name)

    sampled_frames = []
    after_counts = {}
    for label_value in sorted(label_counts):
        label_df = df[df[target_column] == label_value].copy()
        sampled_label_df = sample_rows(
            label_df,
            target_count,
            split_seed + int(label_value),
            stratify_column=get_multiclass_stratify_column(label_df, int(label_value)),
        )
        sampled_frames.append(sampled_label_df)
        after_counts[int(label_value)] = len(sampled_label_df)

    balanced_df = pd.concat(sampled_frames, ignore_index=True)
    balanced_df = balanced_df.sample(frac=1.0, random_state=split_seed + 100).reset_index(drop=True)

    info = {
        "before_counts": {int(key): int(value) for key, value in label_counts.items()},
        "after_counts": after_counts,
        "target_count": int(target_count),
        "rule": "equal_per_label",
    }
    return balanced_df, info


def maybe_balance_splits(train_df, val_df, test_df, target_column):
    if TASK_TYPE == "binary":
        if not BALANCE_BINARY_NORMAL_TO_ATTACK:
            return train_df, val_df, test_df, None

        print("[INFO] Binary balancing enabled: normal rows will be reduced only when normal > attack.")

        balanced_train_df, train_info = balance_binary_split(train_df, "train")
        balanced_val_df, val_info = balance_binary_split(val_df, "val")
        balanced_test_df, test_info = balance_binary_split(test_df, "test")

        for split_name, info in (("train", train_info), ("val", val_info), ("test", test_info)):
            print(
                f"[INFO] {split_name} binary balance: "
                f"normal {info['before_normal']} -> {info['after_normal']}, "
                f"attack {info['before_attack']} -> {info['after_attack']}"
            )

        balance_info = {"mode": "binary", "train": train_info, "val": val_info, "test": test_info}
        return balanced_train_df, balanced_val_df, balanced_test_df, balance_info

    if TASK_TYPE == "multiclass":
        if not BALANCE_MULTICLASS_SPLITS:
            return train_df, val_df, test_df, None

        print("[INFO] Multiclass balancing enabled: each label will use the same row count per split.")

        balanced_train_df, train_info = balance_multiclass_split(train_df, "train", target_column)
        balanced_val_df, val_info = balance_multiclass_split(val_df, "val", target_column)
        balanced_test_df, test_info = balance_multiclass_split(test_df, "test", target_column)

        for split_name, info in (("train", train_info), ("val", val_info), ("test", test_info)):
            print(
                f"[INFO] {split_name} multiclass balance target={info['target_count']} "
                f"labels={len(info['after_counts'])}"
            )

        balance_info = {"mode": "multiclass", "train": train_info, "val": val_info, "test": test_info}
        return balanced_train_df, balanced_val_df, balanced_test_df, balance_info

    return train_df, val_df, test_df, None


def coerce_numeric_frame(df, feature_columns):
    X = df[feature_columns].copy()
    for column in feature_columns:
        X[column] = pd.to_numeric(X[column], errors="coerce")
    return X.replace([np.inf, -np.inf], np.nan)


def compute_fill_values(X_train):
    fill_values = {}
    for column in X_train.columns:
        valid_series = X_train[column].dropna()
        fill_values[column] = float(valid_series.median()) if not valid_series.empty else 0.0
    return fill_values


def apply_fill_values(X, fill_values):
    return X.fillna(fill_values)


def prepare_xy(train_df, val_df, test_df, feature_columns, target_column):
    X_train = coerce_numeric_frame(train_df, feature_columns)
    X_val = coerce_numeric_frame(val_df, feature_columns)
    X_test = coerce_numeric_frame(test_df, feature_columns)

    fill_values = compute_fill_values(X_train)
    X_train = apply_fill_values(X_train, fill_values)
    X_val = apply_fill_values(X_val, fill_values)
    X_test = apply_fill_values(X_test, fill_values)

    y_train = train_df[target_column].copy()
    y_val = val_df[target_column].copy()
    y_test = test_df[target_column].copy()
    return X_train, y_train, X_val, y_val, X_test, y_test, fill_values


def build_model(task_config, enable_early_stopping):
    params = {
        "n_estimators": 400,
        "max_depth": 6,
        "learning_rate": 0.05,
        "subsample": 0.9,
        "colsample_bytree": 0.9,
        "objective": task_config["objective"],
        "eval_metric": task_config["eval_metric"],
        "random_state": RANDOM_STATE,
    }

    if task_config["num_class"] is not None:
        params["num_class"] = task_config["num_class"]

    if enable_early_stopping:
        params["early_stopping_rounds"] = EARLY_STOPPING_ROUNDS

    return XGBClassifier(**params)


def fit_model(task_config, X_train, y_train, X_val, y_val):
    fit_kwargs = {"eval_set": [(X_val, y_val)], "verbose": 25}

    for enable_early_stopping in (True, False):
        model = build_model(task_config, enable_early_stopping)
        try:
            model.fit(X_train, y_train, **fit_kwargs)
            return model, enable_early_stopping
        except (TypeError, ValueError) as exc:
            message = str(exc).lower()
            if enable_early_stopping and "early" in message:
                print("[WARN] Early stopping not supported by this XGBoost build. Retrying without it.")
                continue
            raise

    raise RuntimeError("Model fitting failed.")


def save_classification_report(run_dir, report_text):
    (run_dir / "classification_report.txt").write_text(report_text, encoding="utf-8")


def save_confusion_matrix_outputs(run_dir, cm, target_names):
    cm_df = pd.DataFrame(cm, index=target_names, columns=target_names)
    cm_df.to_csv(run_dir / "confusion_matrix.csv", encoding="utf-8")

    fig, ax = plt.subplots(figsize=(10, 8))
    display = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=target_names)
    display.plot(ax=ax, cmap="Blues", values_format="d", colorbar=False, xticks_rotation=45)
    ax.set_title(f"XGBoost V6 Confusion Matrix ({TASK_TYPE}, {FEATURE_SET})")
    fig.tight_layout()
    fig.savefig(run_dir / "confusion_matrix.png", dpi=180, bbox_inches="tight")
    plt.close(fig)


def save_feature_importance(run_dir, model, feature_columns):
    importance_df = pd.DataFrame(
        {"feature": feature_columns, "importance": model.feature_importances_}
    ).sort_values(by="importance", ascending=False)
    importance_df.to_csv(run_dir / "feature_importance.csv", index=False, encoding="utf-8")

    fig, ax = plt.subplots(figsize=(10, max(6, len(feature_columns) * 0.3)))
    ax.barh(importance_df["feature"], importance_df["importance"], color="#2f6db3")
    ax.set_title(f"XGBoost V6 Feature Importance ({TASK_TYPE}, {FEATURE_SET})")
    ax.set_xlabel("Importance")
    ax.invert_yaxis()
    fig.tight_layout()
    fig.savefig(run_dir / "feature_importance.png", dpi=180, bbox_inches="tight")
    plt.close(fig)
    return importance_df


def label_name_from_id(label_value):
    if TASK_TYPE == "binary":
        return "normal" if int(label_value) == 0 else "attack"
    return CLASS_NAME_BY_ID.get(int(label_value), f"unknown_{label_value}")


def build_predictions_df(test_df, y_true, y_pred, confidence, group_column):
    predictions_df = pd.DataFrame(
        {
            "true_label": y_true,
            "predicted_label": y_pred,
        }
    )
    predictions_df["true_label_name"] = predictions_df["true_label"].map(label_name_from_id)
    predictions_df["predicted_label_name"] = predictions_df["predicted_label"].map(label_name_from_id)
    predictions_df["confidence"] = confidence

    metadata_columns = [
        "attack_type",
        "normal_subtype",
        "gps_spoof_subtype",
        "scenario_id",
        "tick_in_run",
        "window_start_index",
        "window_end_index",
    ]
    if group_column:
        metadata_columns.insert(0, group_column)

    for column_name in metadata_columns:
        if column_name in test_df.columns:
            predictions_df[column_name] = test_df[column_name].reset_index(drop=True)

    return predictions_df


def save_predictions(run_dir, predictions_df):
    predictions_df.to_csv(run_dir / "predictions.csv", index=False, encoding="utf-8")


def save_normal_vs_attack_errors(run_dir, predictions_df):
    error_mask = (
        ((predictions_df["true_label"] == 0) & (predictions_df["predicted_label"] != 0))
        | ((predictions_df["true_label"] != 0) & (predictions_df["predicted_label"] == 0))
    )
    error_df = predictions_df.loc[error_mask].copy()
    error_df.to_csv(run_dir / "normal_vs_attack_errors.csv", index=False, encoding="utf-8")
    return error_df


def save_gps_spoofing_errors(run_dir, predictions_df):
    if TASK_TYPE == "multiclass":
        error_mask = (
            ((predictions_df["true_label"] == 1) & (predictions_df["predicted_label"] != 1))
            | ((predictions_df["true_label"] != 1) & (predictions_df["predicted_label"] == 1))
        )
    else:
        if "attack_type" not in predictions_df.columns:
            error_mask = np.zeros(len(predictions_df), dtype=bool)
        else:
            error_mask = (
                (predictions_df["attack_type"] == "gps_spoofing")
                & (predictions_df["predicted_label"] != 1)
            )
    error_df = predictions_df.loc[error_mask].copy()
    error_df.to_csv(run_dir / "gps_spoofing_errors.csv", index=False, encoding="utf-8")
    return error_df


def save_subtype_error_analyses(run_dir, predictions_df):
    if "attack_type" in predictions_df.columns:
        normal_df = predictions_df[predictions_df["attack_type"] == "normal"].copy()
    else:
        normal_df = pd.DataFrame()
    if not normal_df.empty and "normal_subtype" in normal_df.columns:
        normal_analysis = (
            normal_df.assign(predicted_as_attack=(normal_df["predicted_label"] != 0).astype(int))
            .groupby("normal_subtype", dropna=False)["predicted_as_attack"]
            .agg(["count", "sum"])
            .reset_index()
            .rename(columns={"sum": "predicted_as_attack_count"})
        )
        normal_analysis["error_rate"] = (
            normal_analysis["predicted_as_attack_count"] / normal_analysis["count"]
        ).round(6)
    else:
        normal_analysis = pd.DataFrame(
            columns=["normal_subtype", "count", "predicted_as_attack_count", "error_rate"]
        )
    normal_analysis.to_csv(
        run_dir / "normal_subtype_error_analysis.csv",
        index=False,
        encoding="utf-8",
    )

    if "attack_type" in predictions_df.columns:
        gps_df = predictions_df[predictions_df["attack_type"] == "gps_spoofing"].copy()
    else:
        gps_df = pd.DataFrame()
    if not gps_df.empty and "gps_spoof_subtype" in gps_df.columns:
        expected_label = 1 if TASK_TYPE == "multiclass" else 1
        gps_analysis = (
            gps_df.assign(missed=(gps_df["predicted_label"] != expected_label).astype(int))
            .groupby("gps_spoof_subtype", dropna=False)["missed"]
            .agg(["count", "sum"])
            .reset_index()
            .rename(columns={"sum": "missed_count"})
        )
        gps_analysis["error_rate"] = (gps_analysis["missed_count"] / gps_analysis["count"]).round(6)
    else:
        gps_analysis = pd.DataFrame(
            columns=["gps_spoof_subtype", "count", "missed_count", "error_rate"]
        )
    gps_analysis.to_csv(
        run_dir / "gps_spoof_subtype_error_analysis.csv",
        index=False,
        encoding="utf-8",
    )

    return normal_analysis, gps_analysis


def save_eval_history(run_dir, model, task_config):
    evals_result = model.evals_result()
    history = evals_result.get("validation_0", {}).get(task_config["eval_metric"], [])
    if not history:
        return

    history_df = pd.DataFrame(
        {"iteration": list(range(len(history))), f"validation_{task_config['eval_metric']}": history}
    )
    history_df.to_csv(run_dir / "eval_history.csv", index=False, encoding="utf-8")


def save_run_config(
    run_dir,
    feature_columns,
    skipped_features,
    fill_values,
    train_df,
    val_df,
    test_df,
    group_column,
    balance_info,
):
    balance_mode = balance_info["mode"] if balance_info else "disabled"
    lines = [
        f"TASK_TYPE={TASK_TYPE}",
        f"FEATURE_SET={FEATURE_SET}",
        f"DATASET_DIR={DATASET_DIR}",
        f"BALANCING_MODE={balance_mode}",
        f"TRAIN_ROWS={len(train_df)}",
        f"VAL_ROWS={len(val_df)}",
        f"TEST_ROWS={len(test_df)}",
        f"GROUP_COLUMN={group_column or 'N/A'}",
        f"TRAIN_GROUPS={train_df[group_column].nunique() if group_column else 'N/A'}",
        f"VAL_GROUPS={val_df[group_column].nunique() if group_column else 'N/A'}",
        f"TEST_GROUPS={test_df[group_column].nunique() if group_column else 'N/A'}",
        f"SELECTED_FEATURE_COUNT={len(feature_columns)}",
        "SELECTED_FEATURES=",
        *[f"  - {feature_name}" for feature_name in feature_columns],
        "IMPUTATION_MEDIANS=",
        *[f"  - {feature_name}: {fill_values[feature_name]}" for feature_name in feature_columns],
    ]

    if balance_info:
        lines.append("BALANCE_COUNTS=")
        for split_name in ("train", "val", "test"):
            info = balance_info[split_name]
            if balance_info["mode"] == "binary":
                lines.append(
                    f"  - {split_name}: "
                    f"normal {info['before_normal']} -> {info['after_normal']}, "
                    f"attack {info['before_attack']} -> {info['after_attack']}"
                )
            else:
                before_counts = ", ".join(
                    f"{CLASS_NAME_BY_ID.get(label_id, label_id)}={count}"
                    for label_id, count in sorted(info["before_counts"].items())
                )
                after_counts = ", ".join(
                    f"{CLASS_NAME_BY_ID.get(label_id, label_id)}={count}"
                    for label_id, count in sorted(info["after_counts"].items())
                )
                lines.append(
                    f"  - {split_name}: target={info['target_count']} "
                    f"before[{before_counts}] after[{after_counts}]"
                )

    if FEATURE_SET == "behavior_only":
        lines.append("EXCLUDED_LEAKAGE_LIKE_FEATURES=")
        lines.extend([f"  - {feature_name}" for feature_name in LEAKAGE_LIKE_FEATURES])

    if skipped_features:
        lines.append("SKIPPED_MISSING_OR_FORBIDDEN_FEATURES=")
        lines.extend([f"  - {feature_name}" for feature_name in skipped_features])

    (run_dir / "run_config.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def print_key_metrics(report_dict):
    normal_metrics = report_dict.get("normal", {})
    print(
        f"[INFO] Normal class precision={float(normal_metrics.get('precision', 0.0)):.6f} "
        f"recall={float(normal_metrics.get('recall', 0.0)):.6f} "
        f"f1={float(normal_metrics.get('f1-score', 0.0)):.6f}"
    )
    if TASK_TYPE == "multiclass":
        gps_metrics = report_dict.get("gps_spoofing", {})
        print(
            f"[INFO] GPS spoofing precision={float(gps_metrics.get('precision', 0.0)):.6f} "
            f"recall={float(gps_metrics.get('recall', 0.0)):.6f} "
            f"f1={float(gps_metrics.get('f1-score', 0.0)):.6f}"
        )


def main():
    task_config = get_task_config()
    run_dir = make_run_dir()

    print(f"[INFO] TASK_TYPE={TASK_TYPE}")
    print(f"[INFO] FEATURE_SET={FEATURE_SET}")
    print(f"[INFO] DATASET_DIR={DATASET_DIR}")
    print(f"[INFO] RESULTS_DIR={run_dir}")

    train_df = attach_row_index(load_split("train"))
    val_df = attach_row_index(load_split("val"))
    test_df = attach_row_index(load_split("test"))

    group_column = ensure_group_disjoint(train_df, val_df, test_df)
    train_df, val_df, test_df, balance_info = maybe_balance_splits(
        train_df,
        val_df,
        test_df,
        task_config["target_column"],
    )

    feature_columns, skipped_features = resolve_feature_columns(
        train_df,
        val_df,
        test_df,
        task_config["target_column"],
    )

    print(f"[INFO] Selected feature count: {len(feature_columns)}")
    print(f"[INFO] Selected features: {', '.join(feature_columns)}")
    print("[INFO] Label columns and subtype strings are excluded from model inputs.")
    print(f"[INFO] Train rows: {len(train_df)}")
    print(f"[INFO] Val rows: {len(val_df)}")
    print(f"[INFO] Test rows: {len(test_df)}")

    X_train, y_train, X_val, y_val, X_test, y_test, fill_values = prepare_xy(
        train_df,
        val_df,
        test_df,
        feature_columns,
        task_config["target_column"],
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_val_scaled = scaler.transform(X_val)
    X_test_scaled = scaler.transform(X_test)

    model, early_stopping_used = fit_model(task_config, X_train_scaled, y_train, X_val_scaled, y_val)

    if TASK_TYPE == "binary":
        positive_probabilities = model.predict_proba(X_test_scaled)[:, 1]
        y_pred = (positive_probabilities >= 0.5).astype(int)
        confidence = np.where(y_pred == 1, positive_probabilities, 1.0 - positive_probabilities)
    else:
        class_probabilities = model.predict_proba(X_test_scaled)
        y_pred = model.predict(X_test_scaled)
        confidence = np.max(class_probabilities, axis=1)

    accuracy = accuracy_score(y_test, y_pred)
    balanced_accuracy = balanced_accuracy_score(y_test, y_pred)
    report_text = classification_report(
        y_test,
        y_pred,
        labels=task_config["labels"],
        target_names=task_config["target_names"],
        zero_division=0,
    )
    report_dict = classification_report(
        y_test,
        y_pred,
        labels=task_config["labels"],
        target_names=task_config["target_names"],
        zero_division=0,
        output_dict=True,
    )
    cm = confusion_matrix(y_test, y_pred, labels=task_config["labels"])

    save_classification_report(run_dir, report_text)
    save_confusion_matrix_outputs(run_dir, cm, task_config["target_names"])
    importance_df = save_feature_importance(run_dir, model, feature_columns)
    predictions_df = build_predictions_df(
        test_df,
        y_test.to_numpy(),
        np.asarray(y_pred),
        np.asarray(confidence),
        group_column,
    )
    save_predictions(run_dir, predictions_df)
    normal_error_df = save_normal_vs_attack_errors(run_dir, predictions_df)
    gps_error_df = save_gps_spoofing_errors(run_dir, predictions_df)
    save_subtype_error_analyses(run_dir, predictions_df)
    save_eval_history(run_dir, model, task_config)
    save_run_config(
        run_dir,
        feature_columns,
        skipped_features,
        fill_values,
        train_df,
        val_df,
        test_df,
        group_column,
        balance_info,
    )

    print("\n" + "=" * 100)
    print("XGBOOST V6 RESULTS")
    print("=" * 100)
    print("Accuracy:", accuracy)
    print("Balanced accuracy:", balanced_accuracy)
    print(f"Early stopping used: {early_stopping_used}")
    print("\nClassification Report:")
    print(report_text)
    print("\nConfusion Matrix:")
    print(cm)
    print("\nFeature Importance:")
    print(importance_df)
    print_key_metrics(report_dict)
    print(f"[INFO] Normal-vs-attack error rows saved: {len(normal_error_df)}")
    print(f"[INFO] GPS spoofing error rows saved: {len(gps_error_df)}")
    print(f"[INFO] Results saved under: {run_dir}")


if __name__ == "__main__":
    main()
