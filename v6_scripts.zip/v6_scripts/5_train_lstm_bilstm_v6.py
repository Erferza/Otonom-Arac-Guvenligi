import os
from collections import Counter
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    confusion_matrix,
)
from sklearn.preprocessing import StandardScaler

os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False
    plt = None

tf = None
torch = None
torch_nn = None
TensorDataset = None
DataLoader = None
Sequential = None
EarlyStopping = None
ReduceLROnPlateau = None
LSTM = None
Bidirectional = None
Dense = None
Dropout = None
Input = None
Adam = None
DL_BACKEND = None
TENSORFLOW_IMPORT_ERROR = None
TORCH_IMPORT_ERROR = None


TASK_TYPE = "multiclass"  # "multiclass" or "binary"
FEATURE_SET = "behavior_only"  # "behavior_only" or "full"
MODEL_TYPE = "lstm"  # "lstm" or "bilstm"

def resolve_v6_root() -> Path:
    script_path = Path(__file__).resolve()
    for parent in [script_path.parent, *script_path.parents]:
        if parent.name == "v6":
            return parent
    for parent in script_path.parents:
        candidate = parent / "v6"
        if candidate.exists():
            return candidate
    return script_path.parent / "v6"

V6_ROOT = resolve_v6_root()


def resolve_default_dataset_dir() -> Path:
    return V6_ROOT / "datasets" / "carla_tabular_dataset_v6"


DATASET_DIR = resolve_default_dataset_dir()
RESULTS_ROOT = V6_ROOT / "results" / "lstm_v6"

WINDOW_SIZE = 20
WINDOW_STRIDE = 5

EPOCHS = 30
BATCH_SIZE = 64
LEARNING_RATE = 0.001

USE_CLASS_WEIGHTS = True
NORMAL_CLASS_WEIGHT_MULTIPLIER = 2.0
GPS_CLASS_WEIGHT_MULTIPLIER = 1.5
BALANCE_BINARY_NORMAL_TO_ATTACK = True
BALANCE_MULTICLASS_GROUPS = True

USE_FOCAL_LOSS = False
FOCAL_GAMMA = 2.0
FOCAL_ALPHA = None  # binary: float in [0,1], multiclass: dict/list/tuple or None

EARLY_STOPPING_PATIENCE = 5
REDUCE_LR_PATIENCE = 3
RANDOM_STATE = 42
LOW_NORMAL_RECALL_THRESHOLD = 0.60

CLASS_MAP = {
    "normal": 0,
    "gps_spoofing": 1,
    "position_spoofing": 2,
    "speed_spoofing": 3,
    "sudden_brake": 4,
    "lane_deviation": 5,
    "sensor_noise": 6,
    "dos": 7,
    "delayed_sensor_attack": 8,
    "heading_spoofing": 9,
}

CLASS_NAME_BY_ID = {value: key for key, value in CLASS_MAP.items()}

BEHAVIOR_ONLY_FEATURES = [
    "obs_x",
    "obs_y",
    "obs_z",
    "obs_speed",
    "obs_accel",
    "obs_yaw",
    "road_id",
    "lane_id",
    "throttle",
    "brake",
    "steer",
    "delta_pos_x",
    "delta_pos_y",
    "delta_speed",
    "delta_accel",
    "yaw_error",
    "is_missing",
    "nearest_vehicle_distance",
    "nearest_vehicle_relative_speed",
    "front_vehicle_distance",
    "rear_vehicle_distance",
    "nearby_vehicle_count",
    "traffic_density",
    "speed_change_rate",
    "acceleration_change_rate",
    "yaw_change_rate",
    "position_jump",
]

FULL_FEATURES = BEHAVIOR_ONLY_FEATURES + [
    "gps_drift_magnitude",
    "gps_drift_rate",
    "position_jump_magnitude",
    "position_jump_flag",
    "hard_brake_flag",
    "brake_intensity",
    "deceleration_rate",
    "time_since_brake_start",
    "speed_spoof_ratio",
    "speed_spoof_offset",
    "missing_ratio",
    "stale_packet_flag",
    "packet_delay_steps",
    "sensor_delay_steps",
    "delayed_sensor_flag",
    "heading_spoof_offset",
    "heading_spoof_flag",
]

LEAKAGE_LIKE_FEATURES = [
    "heading_spoof_flag",
    "gps_drift_magnitude",
    "gps_drift_rate",
    "position_jump_magnitude",
    "position_jump_flag",
    "hard_brake_flag",
    "speed_spoof_ratio",
    "missing_ratio",
    "stale_packet_flag",
    "packet_delay_steps",
    "sensor_delay_steps",
    "delayed_sensor_flag",
    "heading_spoof_offset",
]

FORBIDDEN_FEATURE_COLUMNS = {
    "attack_type",
    "normal_subtype",
    "gps_spoof_subtype",
    "binary_label",
    "multiclass_label",
    "attack_run_id",
    "scenario_id",
    "run_id",
    "class_run_id",
    "tick_in_run",
    "vehicle_id",
    "timestamp",
    "frame",
    "map_name",
    "weather_preset",
    "npc_vehicle_count",
    "group_id",
    "__group_id__",
    "__row_index__",
}


def set_random_seeds():
    np.random.seed(RANDOM_STATE)
    if DL_BACKEND == "tensorflow" and tf is not None:
        tf.random.set_seed(RANDOM_STATE)
    if DL_BACKEND == "torch" and torch is not None:
        torch.manual_seed(RANDOM_STATE)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(RANDOM_STATE)


def ensure_deep_learning_backend():
    global DL_BACKEND
    global tf
    global torch
    global torch_nn
    global TensorDataset
    global DataLoader
    global Sequential
    global EarlyStopping
    global ReduceLROnPlateau
    global LSTM
    global Bidirectional
    global Dense
    global Dropout
    global Input
    global Adam
    global TENSORFLOW_IMPORT_ERROR
    global TORCH_IMPORT_ERROR

    if DL_BACKEND is not None:
        return DL_BACKEND

    try:
        import tensorflow as tf_module
        from tensorflow.keras import Sequential as SequentialLayer
        from tensorflow.keras.callbacks import EarlyStopping as EarlyStoppingCallback
        from tensorflow.keras.callbacks import ReduceLROnPlateau as ReduceLROnPlateauCallback
        from tensorflow.keras.layers import LSTM as LSTMLayer
        from tensorflow.keras.layers import Bidirectional as BidirectionalLayer
        from tensorflow.keras.layers import Dense as DenseLayer
        from tensorflow.keras.layers import Dropout as DropoutLayer
        from tensorflow.keras.layers import Input as InputLayer
        from tensorflow.keras.optimizers import Adam as AdamOptimizer
    except Exception as exc:
        TENSORFLOW_IMPORT_ERROR = exc
    else:
        tf = tf_module
        Sequential = SequentialLayer
        EarlyStopping = EarlyStoppingCallback
        ReduceLROnPlateau = ReduceLROnPlateauCallback
        LSTM = LSTMLayer
        Bidirectional = BidirectionalLayer
        Dense = DenseLayer
        Dropout = DropoutLayer
        Input = InputLayer
        Adam = AdamOptimizer
        DL_BACKEND = "tensorflow"
        return DL_BACKEND

    try:
        import torch as torch_module
        import torch.nn as torch_nn_module
        from torch.utils.data import DataLoader as TorchDataLoader
        from torch.utils.data import TensorDataset as TorchTensorDataset
    except Exception as exc:
        TORCH_IMPORT_ERROR = exc
        raise ImportError(
            "No supported deep learning backend could be imported. "
            f"TensorFlow error: {TENSORFLOW_IMPORT_ERROR!r}. "
            f"PyTorch error: {TORCH_IMPORT_ERROR!r}."
        ) from exc

    torch = torch_module
    torch_nn = torch_nn_module
    TensorDataset = TorchTensorDataset
    DataLoader = TorchDataLoader
    DL_BACKEND = "torch"
    return DL_BACKEND


def ensure_tensorflow_available():
    return ensure_deep_learning_backend()


def make_run_dir():
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = RESULTS_ROOT / f"{TASK_TYPE}_{FEATURE_SET}_{MODEL_TYPE}_{timestamp}"
    run_dir.mkdir(parents=True, exist_ok=True)
    return run_dir


def load_split(split_name):
    split_dir = DATASET_DIR / split_name
    combined_file = split_dir / f"{split_name}_combined.csv"

    if combined_file.exists():
        return pd.read_csv(combined_file, low_memory=False)

    files = sorted(split_dir.glob("*/data.csv"))
    dfs = [pd.read_csv(file, low_memory=False) for file in files]
    if not dfs:
        raise RuntimeError(f"No split files found for: {split_name}")
    return pd.concat(dfs, ignore_index=True)


def prepare_group_columns(df):
    df = df.copy()

    if "attack_run_id" in df.columns:
        group_output_column = "attack_run_id"
        df["__group_id__"] = df["attack_run_id"].astype(str)
    elif "scenario_id" in df.columns:
        group_output_column = "scenario_id"
        df["__group_id__"] = df["scenario_id"].astype(str)
    else:
        group_output_column = "group_id"
        vehicle_part = df["vehicle_id"].astype(str) if "vehicle_id" in df.columns else "unknown_vehicle"
        attack_part = df["attack_type"].astype(str) if "attack_type" in df.columns else "unknown_attack"
        df["group_id"] = vehicle_part + "|" + attack_part
        df["__group_id__"] = df["group_id"].astype(str)

    sort_columns = ["__group_id__"]
    for column_name in ("tick_in_run", "frame", "timestamp"):
        if column_name in df.columns:
            sort_columns.append(column_name)

    df = df.sort_values(sort_columns).reset_index(drop=True)
    df["__row_index__"] = np.arange(len(df), dtype=int)
    return df, group_output_column


def ensure_group_disjoint(train_df, val_df, test_df):
    train_groups = set(train_df["__group_id__"].astype(str))
    val_groups = set(val_df["__group_id__"].astype(str))
    test_groups = set(test_df["__group_id__"].astype(str))

    overlaps = {
        "train_val": train_groups & val_groups,
        "train_test": train_groups & test_groups,
        "val_test": val_groups & test_groups,
    }

    overlap_messages = []
    for overlap_name, overlap_values in overlaps.items():
        if overlap_values:
            preview = ", ".join(sorted(overlap_values)[:10])
            overlap_messages.append(f"{overlap_name}: {preview}")

    if overlap_messages:
        raise RuntimeError("Run leakage detected across splits -> " + " | ".join(overlap_messages))


def get_task_config():
    if TASK_TYPE == "binary":
        return {
            "target_column": "binary_label",
            "num_classes": 2,
            "labels": [0, 1],
            "target_names": ["normal", "attack"],
        }

    if TASK_TYPE == "multiclass":
        labels = sorted(CLASS_NAME_BY_ID.keys())
        return {
            "target_column": "multiclass_label",
            "num_classes": 10,
            "labels": labels,
            "target_names": [CLASS_NAME_BY_ID[label] for label in labels],
        }

    raise ValueError(f"Unsupported TASK_TYPE: {TASK_TYPE}")


def get_feature_candidates():
    if FEATURE_SET == "behavior_only":
        return BEHAVIOR_ONLY_FEATURES
    if FEATURE_SET == "full":
        return FULL_FEATURES
    raise ValueError(f"Unsupported FEATURE_SET: {FEATURE_SET}")


def resolve_feature_columns(train_df, val_df, test_df, target_column):
    feature_candidates = get_feature_candidates()
    common_columns = set(train_df.columns) & set(val_df.columns) & set(test_df.columns)
    forbidden_columns = set(FORBIDDEN_FEATURE_COLUMNS)
    forbidden_columns.add(target_column)

    selected_features = []
    skipped_features = []

    for feature_name in feature_candidates:
        if feature_name in forbidden_columns:
            skipped_features.append(feature_name)
        elif feature_name in common_columns:
            selected_features.append(feature_name)
        else:
            skipped_features.append(feature_name)

    if skipped_features:
        print(f"[WARN] Missing or forbidden selected features skipped: {', '.join(skipped_features)}")

    if not selected_features:
        raise RuntimeError("No usable features remain after feature selection.")

    return selected_features, skipped_features


def allocate_sample_counts(group_sizes, target_total):
    if target_total <= 0:
        return {group_name: 0 for group_name in group_sizes}

    total_rows = sum(group_sizes.values())
    if target_total >= total_rows:
        return dict(group_sizes)

    raw_counts = {
        group_name: target_total * group_size / total_rows
        for group_name, group_size in group_sizes.items()
    }
    counts = {
        group_name: int(np.floor(raw_count))
        for group_name, raw_count in raw_counts.items()
    }

    if target_total >= len(group_sizes):
        zero_groups = [group_name for group_name, count in counts.items() if count == 0]
        for group_name in zero_groups:
            donor = max(counts, key=lambda item: counts[item])
            if counts[donor] > 1:
                counts[donor] -= 1
                counts[group_name] += 1

    remainder = target_total - sum(counts.values())
    if remainder > 0:
        fractional_order = sorted(
            group_sizes,
            key=lambda group_name: raw_counts[group_name] - counts[group_name],
            reverse=True,
        )
        for group_name in fractional_order:
            if remainder == 0:
                break
            if counts[group_name] < group_sizes[group_name]:
                counts[group_name] += 1
                remainder -= 1

    return counts


def sample_rows(df, target_total, random_state, stratify_column=None):
    if target_total >= len(df):
        return df.copy()

    if not stratify_column or stratify_column not in df.columns:
        return df.sample(n=target_total, random_state=random_state).copy()

    group_sizes = df.groupby(stratify_column).size().to_dict()
    sample_counts = allocate_sample_counts(group_sizes, target_total)

    sampled_frames = []
    for group_name, group_df in df.groupby(stratify_column, sort=True):
        sample_count = sample_counts.get(group_name, 0)
        if sample_count <= 0:
            continue
        sampled_frames.append(group_df.sample(n=sample_count, random_state=random_state).copy())

    if not sampled_frames:
        raise RuntimeError("Sampling failed; no rows selected.")

    sampled_df = pd.concat(sampled_frames, ignore_index=True)
    return sampled_df.sample(frac=1.0, random_state=random_state).reset_index(drop=True)


def build_group_frame(df, target_column):
    columns = ["__group_id__", target_column]
    for column_name in ("attack_type", "normal_subtype", "gps_spoof_subtype"):
        if column_name in df.columns:
            columns.append(column_name)
    return df[columns].drop_duplicates(subset="__group_id__").reset_index(drop=True)


def get_binary_group_stratify_column(group_df, label_value):
    if label_value == 0 and "normal_subtype" in group_df.columns:
        return "normal_subtype"
    if label_value == 1 and "attack_type" in group_df.columns:
        return "attack_type"
    return None


def get_multiclass_group_stratify_column(group_df, label_value):
    if label_value == CLASS_MAP["normal"] and "normal_subtype" in group_df.columns:
        return "normal_subtype"
    if label_value == CLASS_MAP["gps_spoofing"] and "gps_spoof_subtype" in group_df.columns:
        return "gps_spoof_subtype"
    return None


def balance_binary_group_split(df, split_name):
    group_df = build_group_frame(df, "binary_label")
    normal_groups = group_df[group_df["binary_label"] == 0].copy()
    attack_groups = group_df[group_df["binary_label"] == 1].copy()

    if normal_groups.empty or attack_groups.empty:
        raise RuntimeError(f"Cannot balance binary split {split_name}: one class is empty.")

    target_group_count = min(len(normal_groups), len(attack_groups))
    split_seed = RANDOM_STATE + sum(ord(ch) for ch in split_name)

    sampled_normal_groups = sample_rows(
        normal_groups,
        target_group_count,
        split_seed,
        stratify_column=get_binary_group_stratify_column(normal_groups, 0),
    )
    selected_group_ids = set(sampled_normal_groups["__group_id__"].astype(str))
    selected_group_ids.update(attack_groups["__group_id__"].astype(str).tolist())

    balanced_df = df[df["__group_id__"].astype(str).isin(selected_group_ids)].copy().reset_index(drop=True)
    balanced_group_df = build_group_frame(balanced_df, "binary_label")

    info = {
        "before_normal_groups": len(normal_groups),
        "before_attack_groups": len(attack_groups),
        "after_normal_groups": int((balanced_group_df["binary_label"] == 0).sum()),
        "after_attack_groups": int((balanced_group_df["binary_label"] == 1).sum()),
        "before_rows": len(df),
        "after_rows": len(balanced_df),
        "rule": "normal<=attack",
    }
    return balanced_df, info


def balance_multiclass_group_split(df, split_name, target_column):
    group_df = build_group_frame(df, target_column)
    label_counts = group_df[target_column].value_counts().sort_index().to_dict()
    if not label_counts:
        raise RuntimeError(f"Cannot balance multiclass split {split_name}: split is empty.")

    target_group_count = min(label_counts.values())
    split_seed = RANDOM_STATE + sum(ord(ch) for ch in split_name)

    sampled_group_frames = []
    after_counts = {}
    for label_value in sorted(label_counts):
        label_group_df = group_df[group_df[target_column] == label_value].copy()
        sampled_label_groups = sample_rows(
            label_group_df,
            target_group_count,
            split_seed + int(label_value),
            stratify_column=get_multiclass_group_stratify_column(label_group_df, int(label_value)),
        )
        sampled_group_frames.append(sampled_label_groups)
        after_counts[int(label_value)] = len(sampled_label_groups)

    sampled_groups_df = pd.concat(sampled_group_frames, ignore_index=True)
    selected_group_ids = set(sampled_groups_df["__group_id__"].astype(str))
    balanced_df = df[df["__group_id__"].astype(str).isin(selected_group_ids)].copy().reset_index(drop=True)

    info = {
        "before_group_counts": {int(key): int(value) for key, value in label_counts.items()},
        "after_group_counts": after_counts,
        "target_group_count": int(target_group_count),
        "before_rows": len(df),
        "after_rows": len(balanced_df),
        "rule": "equal_per_label",
    }
    return balanced_df, info


def maybe_balance_group_splits(train_df, val_df, test_df, target_column):
    if TASK_TYPE == "binary":
        if not BALANCE_BINARY_NORMAL_TO_ATTACK:
            return train_df, val_df, test_df, None

        print("[INFO] Binary balancing enabled: normal groups will be reduced only when normal > attack.")

        balanced_train_df, train_info = balance_binary_group_split(train_df, "train")
        balanced_val_df, val_info = balance_binary_group_split(val_df, "val")
        balanced_test_df, test_info = balance_binary_group_split(test_df, "test")

        for split_name, info in (("train", train_info), ("val", val_info), ("test", test_info)):
            print(
                f"[INFO] {split_name} binary group balance: "
                f"normal_groups {info['before_normal_groups']} -> {info['after_normal_groups']}, "
                f"attack_groups {info['before_attack_groups']} -> {info['after_attack_groups']}, "
                f"rows {info['before_rows']} -> {info['after_rows']}"
            )

        return balanced_train_df, balanced_val_df, balanced_test_df, {
            "mode": "binary",
            "train": train_info,
            "val": val_info,
            "test": test_info,
        }

    if TASK_TYPE == "multiclass":
        if not BALANCE_MULTICLASS_GROUPS:
            return train_df, val_df, test_df, None

        print("[INFO] Multiclass balancing enabled: each label will use the same group count per split.")

        balanced_train_df, train_info = balance_multiclass_group_split(train_df, "train", target_column)
        balanced_val_df, val_info = balance_multiclass_group_split(val_df, "val", target_column)
        balanced_test_df, test_info = balance_multiclass_group_split(test_df, "test", target_column)

        for split_name, info in (("train", train_info), ("val", val_info), ("test", test_info)):
            print(
                f"[INFO] {split_name} multiclass group balance: "
                f"target_groups={info['target_group_count']} rows {info['before_rows']} -> {info['after_rows']}"
            )

        return balanced_train_df, balanced_val_df, balanced_test_df, {
            "mode": "multiclass",
            "train": train_info,
            "val": val_info,
            "test": test_info,
        }

    return train_df, val_df, test_df, None


def coerce_numeric_frame(df, feature_columns):
    feature_df = df[feature_columns].copy()
    for column_name in feature_columns:
        feature_df[column_name] = pd.to_numeric(feature_df[column_name], errors="coerce")
    return feature_df.replace([np.inf, -np.inf], np.nan)


def compute_fill_values(train_feature_df):
    fill_values = {}
    for column_name in train_feature_df.columns:
        valid_series = train_feature_df[column_name].dropna()
        fill_values[column_name] = float(valid_series.median()) if not valid_series.empty else 0.0
    return fill_values


def apply_fill_values(feature_df, fill_values):
    return feature_df.fillna(fill_values)


def apply_feature_preprocessing(train_df, val_df, test_df, feature_columns):
    train_features = coerce_numeric_frame(train_df, feature_columns)
    val_features = coerce_numeric_frame(val_df, feature_columns)
    test_features = coerce_numeric_frame(test_df, feature_columns)

    fill_values = compute_fill_values(train_features)
    train_df = train_df.copy()
    val_df = val_df.copy()
    test_df = test_df.copy()

    train_df.loc[:, feature_columns] = apply_fill_values(train_features, fill_values)
    val_df.loc[:, feature_columns] = apply_fill_values(val_features, fill_values)
    test_df.loc[:, feature_columns] = apply_fill_values(test_features, fill_values)

    return train_df, val_df, test_df, fill_values


def format_distribution(labels, label_names):
    counts = Counter(int(value) for value in labels)
    lines = []
    for label_id in sorted(label_names):
        label_name = label_names[label_id]
        lines.append(f"{label_name}: {counts.get(label_id, 0)}")
    return lines


def print_distribution(title, labels, label_names):
    print(f"\n{title}")
    for line in format_distribution(labels, label_names):
        print(f"[INFO] {line}")


def create_windows(df, feature_columns, target_column, group_output_column):
    window_features = []
    window_labels = []
    metadata_rows = []
    skipped_groups = 0

    metadata_candidates = [
        group_output_column,
        "scenario_id",
        "attack_type",
        "normal_subtype",
        "gps_spoof_subtype",
    ]

    for _, group_df in df.groupby("__group_id__", sort=False):
        if len(group_df) < WINDOW_SIZE:
            skipped_groups += 1
            continue

        feature_matrix = group_df[feature_columns].to_numpy(dtype=np.float32)
        label_array = group_df[target_column].to_numpy(dtype=np.int64)
        row_indices = group_df["__row_index__"].to_numpy(dtype=np.int64)

        start_positions = range(0, len(group_df) - WINDOW_SIZE + 1, WINDOW_STRIDE)
        for start_index in start_positions:
            end_exclusive = start_index + WINDOW_SIZE
            end_index = end_exclusive - 1

            window_features.append(feature_matrix[start_index:end_exclusive])
            window_labels.append(int(label_array[end_index]))

            metadata = {
                "window_start_index": int(row_indices[start_index]),
                "window_end_index": int(row_indices[end_index]),
            }
            for column_name in metadata_candidates:
                if column_name in group_df.columns:
                    metadata[column_name] = group_df.iloc[end_index][column_name]
            metadata_rows.append(metadata)

    if not window_features:
        raise RuntimeError("No windows were generated. Check WINDOW_SIZE and split contents.")

    metadata_df = pd.DataFrame(metadata_rows)
    return (
        np.asarray(window_features, dtype=np.float32),
        np.asarray(window_labels, dtype=np.int64),
        metadata_df,
        skipped_groups,
    )


def scale_windows(X_train, X_val, X_test):
    num_features = X_train.shape[-1]
    scaler = StandardScaler()

    X_train_flat = X_train.reshape(-1, num_features)
    X_val_flat = X_val.reshape(-1, num_features)
    X_test_flat = X_test.reshape(-1, num_features)

    X_train_scaled = scaler.fit_transform(X_train_flat).reshape(X_train.shape)
    X_val_scaled = scaler.transform(X_val_flat).reshape(X_val.shape)
    X_test_scaled = scaler.transform(X_test_flat).reshape(X_test.shape)

    return X_train_scaled, X_val_scaled, X_test_scaled, scaler


def build_loss(task_config):
    backend = ensure_deep_learning_backend()

    if backend == "torch":
        if USE_FOCAL_LOSS:
            raise RuntimeError("Torch fallback does not support focal loss in this script.")
        return None

    if not USE_FOCAL_LOSS:
        return "binary_crossentropy" if TASK_TYPE == "binary" else "sparse_categorical_crossentropy"

    gamma = float(FOCAL_GAMMA)

    if TASK_TYPE == "binary":
        alpha = None if FOCAL_ALPHA is None else float(FOCAL_ALPHA)

        def binary_focal_loss(y_true, y_pred):
            y_true_cast = tf.cast(y_true, tf.float32)
            y_pred_clipped = tf.clip_by_value(y_pred, tf.keras.backend.epsilon(), 1.0 - tf.keras.backend.epsilon())
            p_t = y_true_cast * y_pred_clipped + (1.0 - y_true_cast) * (1.0 - y_pred_clipped)
            if alpha is None:
                alpha_factor = 1.0
            else:
                alpha_factor = y_true_cast * alpha + (1.0 - y_true_cast) * (1.0 - alpha)
            loss = -alpha_factor * tf.pow(1.0 - p_t, gamma) * tf.math.log(p_t)
            return tf.reduce_mean(loss)

        return binary_focal_loss

    alpha_lookup = None
    if FOCAL_ALPHA is not None:
        if isinstance(FOCAL_ALPHA, dict):
            alpha_lookup = np.ones(task_config["num_classes"], dtype=np.float32)
            for class_id, alpha_value in FOCAL_ALPHA.items():
                alpha_lookup[int(class_id)] = float(alpha_value)
        elif isinstance(FOCAL_ALPHA, (list, tuple, np.ndarray)):
            alpha_lookup = np.asarray(FOCAL_ALPHA, dtype=np.float32)
        else:
            raise ValueError("FOCAL_ALPHA must be None, dict, list, tuple, or numpy array for multiclass.")

    alpha_tensor = None if alpha_lookup is None else tf.constant(alpha_lookup, dtype=tf.float32)

    def sparse_categorical_focal_loss(y_true, y_pred):
        y_true_flat = tf.cast(tf.reshape(y_true, [-1]), tf.int32)
        y_pred_clipped = tf.clip_by_value(y_pred, tf.keras.backend.epsilon(), 1.0 - tf.keras.backend.epsilon())
        batch_indices = tf.range(tf.shape(y_true_flat)[0], dtype=tf.int32)
        gather_indices = tf.stack([batch_indices, y_true_flat], axis=1)
        p_t = tf.gather_nd(y_pred_clipped, gather_indices)
        if alpha_tensor is None:
            alpha_factor = 1.0
        else:
            alpha_factor = tf.gather(alpha_tensor, y_true_flat)
        loss = -alpha_factor * tf.pow(1.0 - p_t, gamma) * tf.math.log(p_t)
        return tf.reduce_mean(loss)

    return sparse_categorical_focal_loss


def build_model(num_features, task_config):
    backend = ensure_deep_learning_backend()

    if backend == "torch":
        bidirectional = MODEL_TYPE == "bilstm"

        class TorchSequenceModel(torch_nn.Module):
            def __init__(self):
                super().__init__()
                self.lstm1 = torch_nn.LSTM(
                    input_size=num_features,
                    hidden_size=64,
                    batch_first=True,
                    bidirectional=bidirectional,
                )
                self.dropout1 = torch_nn.Dropout(0.3)
                self.lstm2 = torch_nn.LSTM(
                    input_size=64 * (2 if bidirectional else 1),
                    hidden_size=32,
                    batch_first=True,
                    bidirectional=bidirectional,
                )
                self.dropout2 = torch_nn.Dropout(0.3)
                dense_input_dim = 32 * (2 if bidirectional else 1)
                self.fc1 = torch_nn.Linear(dense_input_dim, 64)
                self.relu = torch_nn.ReLU()
                self.output = torch_nn.Linear(
                    64,
                    1 if TASK_TYPE == "binary" else int(task_config["num_classes"]),
                )

            def forward(self, inputs):
                x, _ = self.lstm1(inputs)
                x = self.dropout1(x)
                x, _ = self.lstm2(x)
                x = x[:, -1, :]
                x = self.fc1(x)
                x = self.relu(x)
                x = self.dropout2(x)
                return self.output(x)

        return TorchSequenceModel()

    model = Sequential()
    model.add(Input(shape=(WINDOW_SIZE, num_features)))

    if MODEL_TYPE == "lstm":
        model.add(LSTM(64, return_sequences=True))
        model.add(Dropout(0.3))
        model.add(LSTM(32))
    elif MODEL_TYPE == "bilstm":
        model.add(Bidirectional(LSTM(64, return_sequences=True)))
        model.add(Dropout(0.3))
        model.add(Bidirectional(LSTM(32)))
    else:
        raise ValueError(f"Unsupported MODEL_TYPE: {MODEL_TYPE}")

    model.add(Dense(64, activation="relu"))
    model.add(Dropout(0.3))

    if TASK_TYPE == "binary":
        model.add(Dense(1, activation="sigmoid"))
    else:
        model.add(Dense(task_config["num_classes"], activation="softmax"))

    model.compile(
        optimizer=Adam(learning_rate=LEARNING_RATE),
        loss=build_loss(task_config),
        metrics=["accuracy"],
    )
    return model


class TrainingHistory:
    def __init__(self, history_dict):
        self.history = history_dict


def fit_torch_model(model, task_config, X_train, y_train, X_val, y_val, class_weights):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)

    X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
    X_val_tensor = torch.tensor(X_val, dtype=torch.float32)

    if TASK_TYPE == "binary":
        y_train_tensor = torch.tensor(y_train, dtype=torch.float32)
        y_val_tensor = torch.tensor(y_val, dtype=torch.float32)
    else:
        y_train_tensor = torch.tensor(y_train, dtype=torch.long)
        y_val_tensor = torch.tensor(y_val, dtype=torch.long)

    if TASK_TYPE == "binary":
        base_criterion = torch_nn.BCEWithLogitsLoss(reduction="none")
        if class_weights:
            sample_weight_tensor = torch.tensor(
                [float(class_weights.get(int(label), 1.0)) for label in y_train],
                dtype=torch.float32,
            )
            train_dataset = TensorDataset(X_train_tensor, y_train_tensor, sample_weight_tensor)
        else:
            train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
        val_dataset = TensorDataset(X_val_tensor, y_val_tensor)
    else:
        if class_weights:
            max_class_id = max(int(class_id) for class_id in class_weights)
            weight_values = [1.0] * (max(max_class_id + 1, int(task_config["num_classes"])))
            for class_id, weight_value in class_weights.items():
                weight_values[int(class_id)] = float(weight_value)
            weight_tensor = torch.tensor(weight_values, dtype=torch.float32, device=device)
        else:
            weight_tensor = None
        base_criterion = torch_nn.CrossEntropyLoss(weight=weight_tensor)
        train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
        val_dataset = TensorDataset(X_val_tensor, y_val_tensor)

    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False)

    optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode="min",
        factor=0.5,
        patience=REDUCE_LR_PATIENCE,
    )

    history = {"loss": [], "val_loss": [], "accuracy": [], "val_accuracy": [], "lr": []}
    best_state = None
    best_val_loss = float("inf")
    patience_counter = 0

    for epoch_index in range(EPOCHS):
        model.train()
        train_loss_sum = 0.0
        train_correct = 0
        train_total = 0

        for batch_items in train_loader:
            if TASK_TYPE == "binary" and len(batch_items) == 3:
                batch_x, batch_y, batch_weights = batch_items
                batch_weights = batch_weights.to(device)
            else:
                batch_x, batch_y = batch_items
                batch_weights = None

            batch_x = batch_x.to(device)
            batch_y = batch_y.to(device)

            optimizer.zero_grad()
            logits = model(batch_x)

            if TASK_TYPE == "binary":
                logits = logits.reshape(-1)
                batch_loss_values = base_criterion(logits, batch_y)

                if batch_weights is not None:
                    loss = (batch_loss_values * batch_weights).mean()
                else:
                    loss = batch_loss_values.mean()

                probabilities = torch.sigmoid(logits)
                predictions = (probabilities >= 0.5).long()
                targets = batch_y.long()
            else:
                loss = base_criterion(logits, batch_y)
                predictions = torch.argmax(logits, dim=1)
                targets = batch_y

            loss.backward()
            optimizer.step()

            batch_size_value = len(batch_y)
            train_loss_sum += float(loss.item()) * batch_size_value
            train_correct += int((predictions == targets).sum().item())
            train_total += batch_size_value

        model.eval()
        val_loss_sum = 0.0
        val_correct = 0
        val_total = 0

        with torch.no_grad():
            for batch_x, batch_y in val_loader:
                batch_x = batch_x.to(device)
                batch_y = batch_y.to(device)
                logits = model(batch_x)

                if TASK_TYPE == "binary":
                    logits = logits.reshape(-1)
                    loss = base_criterion(logits, batch_y).mean()
                    probabilities = torch.sigmoid(logits)
                    predictions = (probabilities >= 0.5).long()
                    targets = batch_y.long()
                else:
                    loss = base_criterion(logits, batch_y)
                    predictions = torch.argmax(logits, dim=1)
                    targets = batch_y

                batch_size_value = len(batch_y)
                val_loss_sum += float(loss.item()) * batch_size_value
                val_correct += int((predictions == targets).sum().item())
                val_total += batch_size_value

        train_loss = train_loss_sum / max(train_total, 1)
        val_loss = val_loss_sum / max(val_total, 1)
        train_accuracy = train_correct / max(train_total, 1)
        val_accuracy = val_correct / max(val_total, 1)
        current_lr = float(optimizer.param_groups[0]["lr"])

        history["loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        history["accuracy"].append(train_accuracy)
        history["val_accuracy"].append(val_accuracy)
        history["lr"].append(current_lr)

        print(
            f"[INFO] Epoch {epoch_index + 1}/{EPOCHS} "
            f"loss={train_loss:.6f} val_loss={val_loss:.6f} "
            f"accuracy={train_accuracy:.6f} val_accuracy={val_accuracy:.6f}"
        )

        scheduler.step(val_loss)

        if val_loss < best_val_loss - 1e-6:
            best_val_loss = val_loss
            best_state = {
                key: value.detach().cpu().clone()
                for key, value in model.state_dict().items()
            }
            patience_counter = 0
        else:
            patience_counter += 1
            if patience_counter >= EARLY_STOPPING_PATIENCE:
                print(f"[INFO] Early stopping triggered at epoch {epoch_index + 1}.")
                break

    if best_state is not None:
        model.load_state_dict(best_state)

    return model, TrainingHistory(history)


def compute_class_weights(y_train):
    if not USE_CLASS_WEIGHTS:
        return None

    counts = Counter(int(value) for value in y_train)
    total = len(y_train)
    num_classes = len(counts)

    class_weights = {}
    for class_id, class_count in counts.items():
        class_weights[class_id] = total / (num_classes * class_count)

    if 0 in class_weights:
        class_weights[0] *= NORMAL_CLASS_WEIGHT_MULTIPLIER

    if TASK_TYPE == "multiclass" and 1 in class_weights:
        class_weights[1] *= GPS_CLASS_WEIGHT_MULTIPLIER

    return class_weights


def label_name_from_id(label_value):
    if TASK_TYPE == "binary":
        return "normal" if int(label_value) == 0 else "attack"
    return CLASS_NAME_BY_ID.get(int(label_value), f"unknown_{label_value}")


def save_model_summary(run_dir, model):
    if DL_BACKEND == "torch":
        parameter_count = sum(parameter.numel() for parameter in model.parameters())
        lines = [str(model), "", f"Total parameters: {parameter_count}"]
    else:
        lines = []
        model.summary(print_fn=lines.append)
    (run_dir / "model_summary.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def save_classification_report(run_dir, report_text):
    (run_dir / "classification_report.txt").write_text(report_text, encoding="utf-8")


def save_confusion_matrix_csv(run_dir, cm, target_names):
    cm_df = pd.DataFrame(cm, index=target_names, columns=target_names)
    cm_df.to_csv(run_dir / "confusion_matrix.csv", encoding="utf-8")


def save_confusion_matrix_plot(run_dir, cm, target_names):
    if not MATPLOTLIB_AVAILABLE:
        print("[WARN] matplotlib is not available; confusion matrix plot skipped.")
        return

    fig, ax = plt.subplots(figsize=(10, 8))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks(np.arange(len(target_names)))
    ax.set_yticks(np.arange(len(target_names)))
    ax.set_xticklabels(target_names, rotation=45, ha="right")
    ax.set_yticklabels(target_names)
    ax.set_title(f"{MODEL_TYPE.upper()} Confusion Matrix ({TASK_TYPE}, {FEATURE_SET})")
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")

    for row_index in range(cm.shape[0]):
        for col_index in range(cm.shape[1]):
            ax.text(col_index, row_index, str(cm[row_index, col_index]), ha="center", va="center")

    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(run_dir / "confusion_matrix.png", dpi=180, bbox_inches="tight")
    plt.close(fig)


def save_training_history(run_dir, history):
    history_df = pd.DataFrame(history.history)
    history_df.insert(0, "epoch", np.arange(1, len(history_df) + 1))
    history_df.to_csv(run_dir / "training_history.csv", index=False, encoding="utf-8")

    if not MATPLOTLIB_AVAILABLE:
        print("[WARN] matplotlib is not available; training plots skipped.")
        return

    if "loss" in history.history:
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.plot(history.history["loss"], label="train_loss")
        if "val_loss" in history.history:
            ax.plot(history.history["val_loss"], label="val_loss")
        ax.set_title("Training Loss")
        ax.set_xlabel("Epoch")
        ax.set_ylabel("Loss")
        ax.legend()
        fig.tight_layout()
        fig.savefig(run_dir / "training_loss.png", dpi=180, bbox_inches="tight")
        plt.close(fig)

    accuracy_key = "accuracy" if "accuracy" in history.history else None
    val_accuracy_key = "val_accuracy" if "val_accuracy" in history.history else None
    if accuracy_key:
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.plot(history.history[accuracy_key], label="train_accuracy")
        if val_accuracy_key:
            ax.plot(history.history[val_accuracy_key], label="val_accuracy")
        ax.set_title("Training Accuracy")
        ax.set_xlabel("Epoch")
        ax.set_ylabel("Accuracy")
        ax.legend()
        fig.tight_layout()
        fig.savefig(run_dir / "training_accuracy.png", dpi=180, bbox_inches="tight")
        plt.close(fig)


def save_predictions(run_dir, metadata_df, y_true, y_pred, confidence):
    predictions_df = metadata_df.copy()
    predictions_df.insert(0, "true_label", y_true)
    predictions_df.insert(1, "predicted_label", y_pred)
    predictions_df.insert(2, "true_label_name", [label_name_from_id(value) for value in y_true])
    predictions_df.insert(3, "predicted_label_name", [label_name_from_id(value) for value in y_pred])
    predictions_df.insert(4, "confidence", confidence)
    predictions_df.to_csv(run_dir / "predictions.csv", index=False, encoding="utf-8")
    return predictions_df


def save_normal_vs_attack_errors(run_dir, predictions_df):
    error_mask = (
        ((predictions_df["true_label"] == 0) & (predictions_df["predicted_label"] != 0))
        | ((predictions_df["true_label"] != 0) & (predictions_df["predicted_label"] == 0))
    )
    error_df = predictions_df.loc[error_mask].copy()
    error_df.to_csv(run_dir / "normal_vs_attack_errors.csv", index=False, encoding="utf-8")
    return error_df


def save_gps_spoofing_errors(run_dir, predictions_df):
    if TASK_TYPE == "multiclass":
        error_mask = (
            ((predictions_df["true_label"] == 1) & (predictions_df["predicted_label"] != 1))
            | ((predictions_df["true_label"] != 1) & (predictions_df["predicted_label"] == 1))
        )
    else:
        if "attack_type" not in predictions_df.columns:
            error_mask = np.zeros(len(predictions_df), dtype=bool)
        else:
            error_mask = (
                (predictions_df["attack_type"] == "gps_spoofing")
                & (predictions_df["predicted_label"] != 1)
            )
    error_df = predictions_df.loc[error_mask].copy()
    error_df.to_csv(run_dir / "gps_spoofing_errors.csv", index=False, encoding="utf-8")
    return error_df


def save_subtype_error_analyses(run_dir, predictions_df):
    if "attack_type" in predictions_df.columns:
        normal_df = predictions_df[predictions_df["attack_type"] == "normal"].copy()
    else:
        normal_df = pd.DataFrame()

    if not normal_df.empty and "normal_subtype" in normal_df.columns:
        normal_analysis = (
            normal_df.assign(predicted_as_attack=(normal_df["predicted_label"] != 0).astype(int))
            .groupby("normal_subtype", dropna=False)["predicted_as_attack"]
            .agg(["count", "sum"])
            .reset_index()
            .rename(columns={"sum": "predicted_as_attack_count"})
        )
        normal_analysis["error_rate"] = (
            normal_analysis["predicted_as_attack_count"] / normal_analysis["count"]
        ).round(6)
    else:
        normal_analysis = pd.DataFrame(
            columns=["normal_subtype", "count", "predicted_as_attack_count", "error_rate"]
        )
    normal_analysis.to_csv(
        run_dir / "normal_subtype_error_analysis.csv",
        index=False,
        encoding="utf-8",
    )

    if "attack_type" in predictions_df.columns:
        gps_df = predictions_df[predictions_df["attack_type"] == "gps_spoofing"].copy()
    else:
        gps_df = pd.DataFrame()

    if not gps_df.empty and "gps_spoof_subtype" in gps_df.columns:
        expected_label = 1 if TASK_TYPE in {"multiclass", "binary"} else 1
        gps_analysis = (
            gps_df.assign(missed=(gps_df["predicted_label"] != expected_label).astype(int))
            .groupby("gps_spoof_subtype", dropna=False)["missed"]
            .agg(["count", "sum"])
            .reset_index()
            .rename(columns={"sum": "missed_count"})
        )
        gps_analysis["error_rate"] = (gps_analysis["missed_count"] / gps_analysis["count"]).round(6)
    else:
        gps_analysis = pd.DataFrame(
            columns=["gps_spoof_subtype", "count", "missed_count", "error_rate"]
        )
    gps_analysis.to_csv(
        run_dir / "gps_spoof_subtype_error_analysis.csv",
        index=False,
        encoding="utf-8",
    )

    return normal_analysis, gps_analysis


def save_run_config(
    run_dir,
    task_config,
    feature_columns,
    skipped_features,
    fill_values,
    balance_info,
    group_output_column,
    train_df,
    val_df,
    test_df,
    y_train_rows,
    y_val_rows,
    y_test_rows,
    y_train_windows,
    y_val_windows,
    y_test_windows,
    class_weights,
):
    label_name_map = {label: name for label, name in zip(task_config["labels"], task_config["target_names"])}
    balance_mode = balance_info["mode"] if balance_info else "disabled"

    lines = [
        f"TASK_TYPE={TASK_TYPE}",
        f"FEATURE_SET={FEATURE_SET}",
        f"MODEL_TYPE={MODEL_TYPE}",
        f"DL_BACKEND={DL_BACKEND}",
        f"DATASET_DIR={DATASET_DIR}",
        f"BALANCING_MODE={balance_mode}",
        f"WINDOW_SIZE={WINDOW_SIZE}",
        f"WINDOW_STRIDE={WINDOW_STRIDE}",
        f"EPOCHS={EPOCHS}",
        f"BATCH_SIZE={BATCH_SIZE}",
        f"LEARNING_RATE={LEARNING_RATE}",
        f"USE_CLASS_WEIGHTS={USE_CLASS_WEIGHTS}",
        f"NORMAL_CLASS_WEIGHT_MULTIPLIER={NORMAL_CLASS_WEIGHT_MULTIPLIER}",
        f"GPS_CLASS_WEIGHT_MULTIPLIER={GPS_CLASS_WEIGHT_MULTIPLIER}",
        f"USE_FOCAL_LOSS={USE_FOCAL_LOSS}",
        f"FOCAL_GAMMA={FOCAL_GAMMA}",
        f"FOCAL_ALPHA={FOCAL_ALPHA}",
        f"GROUP_COLUMN={group_output_column}",
        f"TRAIN_ROWS={len(train_df)}",
        f"VAL_ROWS={len(val_df)}",
        f"TEST_ROWS={len(test_df)}",
        f"TRAIN_WINDOWS={len(y_train_windows)}",
        f"VAL_WINDOWS={len(y_val_windows)}",
        f"TEST_WINDOWS={len(y_test_windows)}",
        f"SELECTED_FEATURE_COUNT={len(feature_columns)}",
        "SELECTED_FEATURES=",
        *[f"  - {feature_name}" for feature_name in feature_columns],
        "ROW_CLASS_DISTRIBUTION_TRAIN=",
        *[f"  - {line}" for line in format_distribution(y_train_rows, label_name_map)],
        "ROW_CLASS_DISTRIBUTION_VAL=",
        *[f"  - {line}" for line in format_distribution(y_val_rows, label_name_map)],
        "ROW_CLASS_DISTRIBUTION_TEST=",
        *[f"  - {line}" for line in format_distribution(y_test_rows, label_name_map)],
        "WINDOW_CLASS_DISTRIBUTION_TRAIN=",
        *[f"  - {line}" for line in format_distribution(y_train_windows, label_name_map)],
        "WINDOW_CLASS_DISTRIBUTION_VAL=",
        *[f"  - {line}" for line in format_distribution(y_val_windows, label_name_map)],
        "WINDOW_CLASS_DISTRIBUTION_TEST=",
        *[f"  - {line}" for line in format_distribution(y_test_windows, label_name_map)],
        "IMPUTATION_MEDIANS=",
        *[f"  - {feature_name}: {fill_values[feature_name]}" for feature_name in feature_columns],
    ]

    if balance_info:
        lines.append("BALANCE_COUNTS=")
        for split_name in ("train", "val", "test"):
            info = balance_info[split_name]
            if balance_info["mode"] == "binary":
                lines.append(
                    f"  - {split_name}: "
                    f"normal_groups {info['before_normal_groups']} -> {info['after_normal_groups']}, "
                    f"attack_groups {info['before_attack_groups']} -> {info['after_attack_groups']}, "
                    f"rows {info['before_rows']} -> {info['after_rows']}"
                )
            else:
                before_counts = ", ".join(
                    f"{CLASS_NAME_BY_ID.get(label_id, label_id)}={count}"
                    for label_id, count in sorted(info["before_group_counts"].items())
                )
                after_counts = ", ".join(
                    f"{CLASS_NAME_BY_ID.get(label_id, label_id)}={count}"
                    for label_id, count in sorted(info["after_group_counts"].items())
                )
                lines.append(
                    f"  - {split_name}: target_groups={info['target_group_count']} "
                    f"rows {info['before_rows']} -> {info['after_rows']} "
                    f"before[{before_counts}] after[{after_counts}]"
                )

    if class_weights:
        lines.append("CLASS_WEIGHTS=")
        for class_id in sorted(class_weights):
            lines.append(f"  - {label_name_from_id(class_id)} ({class_id}): {class_weights[class_id]}")

    if FEATURE_SET == "behavior_only":
        lines.append("EXCLUDED_LEAKAGE_LIKE_FEATURES=")
        lines.extend([f"  - {feature_name}" for feature_name in LEAKAGE_LIKE_FEATURES])

    if skipped_features:
        lines.append("SKIPPED_MISSING_OR_FORBIDDEN_FEATURES=")
        lines.extend([f"  - {feature_name}" for feature_name in skipped_features])

    (run_dir / "run_config.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def get_prediction_outputs(model, X_test):
    if DL_BACKEND == "torch":
        device = next(model.parameters()).device
        model.eval()
        test_tensor = torch.tensor(X_test, dtype=torch.float32)
        test_loader = DataLoader(TensorDataset(test_tensor), batch_size=BATCH_SIZE, shuffle=False)
        probability_chunks = []

        with torch.no_grad():
            for (batch_x,) in test_loader:
                logits = model(batch_x.to(device))
                if TASK_TYPE == "binary":
                    probabilities = torch.sigmoid(logits.reshape(-1))
                else:
                    probabilities = torch.softmax(logits, dim=1)
                probability_chunks.append(probabilities.cpu().numpy())

        if TASK_TYPE == "binary":
            probabilities = np.concatenate(probability_chunks, axis=0).reshape(-1)
            y_pred = (probabilities >= 0.5).astype(int)
            confidence = np.where(y_pred == 1, probabilities, 1.0 - probabilities)
            return y_pred, confidence

        probabilities = np.concatenate(probability_chunks, axis=0)
        y_pred = np.argmax(probabilities, axis=1)
        confidence = np.max(probabilities, axis=1)
        return y_pred.astype(int), confidence.astype(float)

    if TASK_TYPE == "binary":
        probabilities = model.predict(X_test, verbose=0).reshape(-1)
        y_pred = (probabilities >= 0.5).astype(int)
        confidence = np.where(y_pred == 1, probabilities, 1.0 - probabilities)
        return y_pred, confidence

    probabilities = model.predict(X_test, verbose=0)
    y_pred = np.argmax(probabilities, axis=1)
    confidence = np.max(probabilities, axis=1)
    return y_pred.astype(int), confidence.astype(float)


def print_class_metrics(report_dict):
    normal_metrics = report_dict.get("normal", {})
    normal_precision = float(normal_metrics.get("precision", 0.0))
    normal_recall = float(normal_metrics.get("recall", 0.0))
    normal_f1 = float(normal_metrics.get("f1-score", 0.0))
    print(
        f"[INFO] Normal class precision={normal_precision:.6f} "
        f"recall={normal_recall:.6f} f1={normal_f1:.6f}"
    )

    if TASK_TYPE == "multiclass":
        gps_metrics = report_dict.get("gps_spoofing", {})
        print(
            f"[INFO] GPS spoofing precision={float(gps_metrics.get('precision', 0.0)):.6f} "
            f"recall={float(gps_metrics.get('recall', 0.0)):.6f} "
            f"f1={float(gps_metrics.get('f1-score', 0.0)):.6f}"
        )

    return normal_precision, normal_recall, normal_f1


def print_recommendations(accuracy, normal_recall):
    if TASK_TYPE == "multiclass" and FEATURE_SET == "behavior_only":
        if accuracy > 0.600222:
            print(
                "[RECOMMENDATION] Temporal modeling helped: this run improved over "
                "the V3 XGBoost multiclass_behavior_only baseline (0.600222)."
            )
        else:
            print(
                "[RECOMMENDATION] Temporal modeling did not improve over "
                "the V3 XGBoost multiclass_behavior_only baseline (0.600222)."
            )

    if normal_recall < LOW_NORMAL_RECALL_THRESHOLD:
        print(
            "[RECOMMENDATION] Normal recall is still low; normal behavior likely needs "
            "richer normal scenario generation or a normal-specific thresholding strategy."
        )

    if TASK_TYPE == "binary" and FEATURE_SET == "full":
        if accuracy > 0.741111:
            print(
                "[RECOMMENDATION] Sequence modeling improves practical IDS detection "
                "over the V3 XGBoost binary_full baseline (0.741111)."
            )
        else:
            print(
                "[RECOMMENDATION] Sequence modeling did not improve over "
                "the V3 XGBoost binary_full baseline (0.741111)."
            )


def main():
    backend = ensure_deep_learning_backend()
    set_random_seeds()
    task_config = get_task_config()
    run_dir = make_run_dir()

    print(f"[INFO] TASK_TYPE={TASK_TYPE}")
    print(f"[INFO] FEATURE_SET={FEATURE_SET}")
    print(f"[INFO] MODEL_TYPE={MODEL_TYPE}")
    print(f"[INFO] DL_BACKEND={backend}")
    print(f"[INFO] DATASET_DIR={DATASET_DIR}")
    print(f"[INFO] RESULTS_DIR={run_dir}")

    train_df = load_split("train")
    val_df = load_split("val")
    test_df = load_split("test")

    train_df, group_output_column = prepare_group_columns(train_df)
    val_df, _ = prepare_group_columns(val_df)
    test_df, _ = prepare_group_columns(test_df)

    ensure_group_disjoint(train_df, val_df, test_df)
    print(f"[INFO] Leakage guard passed with group column: {group_output_column}")

    train_df, val_df, test_df, balance_info = maybe_balance_group_splits(
        train_df,
        val_df,
        test_df,
        task_config["target_column"],
    )

    feature_columns, skipped_features = resolve_feature_columns(
        train_df,
        val_df,
        test_df,
        task_config["target_column"],
    )

    print(f"[INFO] Selected feature count: {len(feature_columns)}")
    print(f"[INFO] Selected features: {', '.join(feature_columns)}")
    print("[INFO] Label columns, subtype strings, and run identifiers are excluded from model inputs.")

    train_df, val_df, test_df, fill_values = apply_feature_preprocessing(
        train_df,
        val_df,
        test_df,
        feature_columns,
    )

    y_train_rows = train_df[task_config["target_column"]].to_numpy(dtype=np.int64)
    y_val_rows = val_df[task_config["target_column"]].to_numpy(dtype=np.int64)
    y_test_rows = test_df[task_config["target_column"]].to_numpy(dtype=np.int64)

    label_name_map = {label: name for label, name in zip(task_config["labels"], task_config["target_names"])}

    print(f"[INFO] Train rows: {len(train_df)}")
    print(f"[INFO] Val rows: {len(val_df)}")
    print(f"[INFO] Test rows: {len(test_df)}")

    print_distribution("Class distribution before windowing - train", y_train_rows, label_name_map)
    print_distribution("Class distribution before windowing - val", y_val_rows, label_name_map)
    print_distribution("Class distribution before windowing - test", y_test_rows, label_name_map)

    X_train, y_train, train_meta, skipped_train_groups = create_windows(
        train_df,
        feature_columns,
        task_config["target_column"],
        group_output_column,
    )
    X_val, y_val, val_meta, skipped_val_groups = create_windows(
        val_df,
        feature_columns,
        task_config["target_column"],
        group_output_column,
    )
    X_test, y_test, test_meta, skipped_test_groups = create_windows(
        test_df,
        feature_columns,
        task_config["target_column"],
        group_output_column,
    )

    print(f"\n[INFO] Train windows: {len(X_train)}")
    print(f"[INFO] Val windows: {len(X_val)}")
    print(f"[INFO] Test windows: {len(X_test)}")
    print(f"[INFO] Skipped short train groups: {skipped_train_groups}")
    print(f"[INFO] Skipped short val groups: {skipped_val_groups}")
    print(f"[INFO] Skipped short test groups: {skipped_test_groups}")

    print_distribution("Class distribution after windowing - train", y_train, label_name_map)
    print_distribution("Class distribution after windowing - val", y_val, label_name_map)
    print_distribution("Class distribution after windowing - test", y_test, label_name_map)

    X_train_scaled, X_val_scaled, X_test_scaled, _ = scale_windows(X_train, X_val, X_test)

    model = build_model(num_features=len(feature_columns), task_config=task_config)
    save_model_summary(run_dir, model)

    class_weights = compute_class_weights(y_train)
    if class_weights:
        print("[INFO] Class weights:")
        for class_id in sorted(class_weights):
            print(f"[INFO]   {label_name_from_id(class_id)} ({class_id}) -> {class_weights[class_id]:.6f}")

    if backend == "tensorflow":
        callbacks = [
            EarlyStopping(
                monitor="val_loss",
                patience=EARLY_STOPPING_PATIENCE,
                restore_best_weights=True,
            ),
            ReduceLROnPlateau(
                monitor="val_loss",
                factor=0.5,
                patience=REDUCE_LR_PATIENCE,
                verbose=1,
            ),
        ]

        history = model.fit(
            X_train_scaled,
            y_train,
            validation_data=(X_val_scaled, y_val),
            epochs=EPOCHS,
            batch_size=BATCH_SIZE,
            class_weight=class_weights,
            callbacks=callbacks,
            verbose=1,
        )
    else:
        model, history = fit_torch_model(
            model,
            task_config,
            X_train_scaled,
            y_train,
            X_val_scaled,
            y_val,
            class_weights,
        )

    y_pred, confidence = get_prediction_outputs(model, X_test_scaled)

    report_text = classification_report(
        y_test,
        y_pred,
        labels=task_config["labels"],
        target_names=task_config["target_names"],
        zero_division=0,
    )
    report_dict = classification_report(
        y_test,
        y_pred,
        labels=task_config["labels"],
        target_names=task_config["target_names"],
        zero_division=0,
        output_dict=True,
    )
    cm = confusion_matrix(y_test, y_pred, labels=task_config["labels"])
    accuracy = accuracy_score(y_test, y_pred)
    balanced_accuracy = balanced_accuracy_score(y_test, y_pred)

    save_classification_report(run_dir, report_text)
    save_confusion_matrix_csv(run_dir, cm, task_config["target_names"])
    save_confusion_matrix_plot(run_dir, cm, task_config["target_names"])
    save_training_history(run_dir, history)

    predictions_df = save_predictions(
        run_dir,
        test_meta,
        y_test,
        y_pred,
        confidence,
    )
    normal_error_df = save_normal_vs_attack_errors(run_dir, predictions_df)
    gps_error_df = save_gps_spoofing_errors(run_dir, predictions_df)
    save_subtype_error_analyses(run_dir, predictions_df)
    save_run_config(
        run_dir,
        task_config,
        feature_columns,
        skipped_features,
        fill_values,
        balance_info,
        group_output_column,
        train_df,
        val_df,
        test_df,
        y_train_rows,
        y_val_rows,
        y_test_rows,
        y_train,
        y_val,
        y_test,
        class_weights,
    )

    print("\n" + "=" * 100)
    print("LSTM/BILSTM V6 RESULTS")
    print("=" * 100)
    print(f"Accuracy: {accuracy:.6f}")
    print(f"Balanced accuracy: {balanced_accuracy:.6f}")
    print("\nClassification Report:")
    print(report_text)
    print("\nConfusion Matrix:")
    print(cm)
    _, normal_recall, _ = print_class_metrics(report_dict)
    print(f"[INFO] Normal-vs-attack error windows saved: {len(normal_error_df)}")
    print(f"[INFO] GPS spoofing error windows saved: {len(gps_error_df)}")
    print(f"[INFO] Results saved under: {run_dir}")

    print_recommendations(accuracy, normal_recall)


if __name__ == "__main__":
    main()


# TODO: Next-stage CIC -> CARLA transfer pipeline
# - Train a source model on CIC / CICFlowMeter-style network intrusion features.
# - Train a target model on CARLA V6 behavior features.
# - Compare direct transfer, feature alignment, and domain adaptation strategies.
# - Investigate whether generic anomaly patterns from CIC improve CARLA binary attack detection.
