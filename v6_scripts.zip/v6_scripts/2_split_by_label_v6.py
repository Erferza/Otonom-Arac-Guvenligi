from pathlib import Path
import math
import random
import shutil

import pandas as pd


def resolve_v6_root() -> Path:
    script_path = Path(__file__).resolve()
    for parent in [script_path.parent, *script_path.parents]:
        if parent.name == "v6":
            return parent
    for parent in script_path.parents:
        candidate = parent / "v6"
        if candidate.exists():
            return candidate
    return script_path.parent / "v6"


V6_ROOT = resolve_v6_root()


def resolve_default_dataset_dir() -> Path:
    return V6_ROOT / "datasets" / "carla_tabular_dataset_v6"


DATASET_DIR = resolve_default_dataset_dir()
RAW_FILE = DATASET_DIR / "raw" / "carla_raw_dataset.csv"
LABEL_COLUMN = "attack_type"
GROUP_COLUMN_CANDIDATES = ("attack_run_id", "run_id", "scenario_id")
SORT_COLUMNS = ("attack_type", "attack_run_id", "tick_in_run", "frame")
SPLITS = ("train", "val", "test")

TRAIN_RATIO = 0.70
VAL_RATIO = 0.15
TEST_RATIO = 0.15
RANDOM_STATE = 42


def validate_config():
    ratio_sum = TRAIN_RATIO + VAL_RATIO + TEST_RATIO
    if abs(ratio_sum - 1.0) > 1e-9:
        raise ValueError(f"Split ratios must sum to 1.0, got {ratio_sum}")


def resolve_group_column(df):
    for column_name in GROUP_COLUMN_CANDIDATES:
        if column_name in df.columns:
            return column_name
    raise KeyError(f"No run/group column found. Tried: {GROUP_COLUMN_CANDIDATES}")


def reset_split_dirs():
    for split_name in SPLITS:
        split_dir = DATASET_DIR / split_name
        if split_dir.exists():
            shutil.rmtree(split_dir)
        split_dir.mkdir(parents=True, exist_ok=True)


def allocate_group_counts(total_groups):
    raw_counts = [
        total_groups * TRAIN_RATIO,
        total_groups * VAL_RATIO,
        total_groups * TEST_RATIO,
    ]
    counts = [math.floor(value) for value in raw_counts]
    remainder = total_groups - sum(counts)

    fractional_order = sorted(
        range(3),
        key=lambda index: raw_counts[index] - counts[index],
        reverse=True,
    )
    for index in fractional_order[:remainder]:
        counts[index] += 1

    if total_groups >= 3:
        for index in (1, 2):
            if counts[index] == 0:
                donor_index = max(range(3), key=lambda item: counts[item])
                if counts[donor_index] > 1:
                    counts[donor_index] -= 1
                    counts[index] += 1

    if sum(counts) != total_groups:
        raise RuntimeError("Group count allocation failed.")

    return {
        "train": counts[0],
        "val": counts[1],
        "test": counts[2],
    }


def assign_groups_per_label(df, group_column):
    split_frames = {split_name: [] for split_name in SPLITS}
    manifest_rows = []

    for label, label_df in df.groupby(LABEL_COLUMN, sort=True):
        group_ids = sorted(label_df[group_column].dropna().unique().tolist())
        if not group_ids:
            raise RuntimeError(f"No groups found for label: {label}")

        rng = random.Random(f"{RANDOM_STATE}:{label}")
        rng.shuffle(group_ids)

        split_group_counts = allocate_group_counts(len(group_ids))
        train_end = split_group_counts["train"]
        val_end = train_end + split_group_counts["val"]

        split_to_groups = {
            "train": group_ids[:train_end],
            "val": group_ids[train_end:val_end],
            "test": group_ids[val_end:],
        }

        print(
            f"[INFO] {label:<24} runs={len(group_ids):>2} "
            f"train_runs={len(split_to_groups['train']):>2} "
            f"val_runs={len(split_to_groups['val']):>2} "
            f"test_runs={len(split_to_groups['test']):>2}"
        )

        for split_name, selected_groups in split_to_groups.items():
            split_df = label_df[label_df[group_column].isin(selected_groups)].copy()
            split_frames[split_name].append(split_df)

            for group_id in selected_groups:
                run_df = label_df[label_df[group_column] == group_id]
                manifest_rows.append(
                    {
                        "split": split_name,
                        "attack_type": label,
                        group_column: group_id,
                        "rows": len(run_df),
                    }
                )

    return split_frames, manifest_rows


def sort_split_df(df):
    sort_columns = [column for column in SORT_COLUMNS if column in df.columns]
    if sort_columns:
        return df.sort_values(sort_columns).reset_index(drop=True)
    return df.reset_index(drop=True)


def save_split(df, split_name):
    split_dir = DATASET_DIR / split_name
    split_df = sort_split_df(df)

    for label, group in split_df.groupby(LABEL_COLUMN, sort=True):
        label_dir = split_dir / label
        label_dir.mkdir(parents=True, exist_ok=True)
        output_file = label_dir / "data.csv"
        group.to_csv(output_file, index=False, encoding="utf-8")

    combined_file = split_dir / f"{split_name}_combined.csv"
    split_df.to_csv(combined_file, index=False, encoding="utf-8")


def print_split_distribution(name, df, group_column):
    print(f"\n{name.upper()}")
    print(df[LABEL_COLUMN].value_counts().sort_index())
    group_counts = df.groupby(LABEL_COLUMN)[group_column].nunique().sort_index()
    print("\nRun counts:")
    print(group_counts)


def main():
    validate_config()

    if not RAW_FILE.exists():
        raise FileNotFoundError(f"Raw file not found: {RAW_FILE}")

    df = pd.read_csv(RAW_FILE, low_memory=False)
    if LABEL_COLUMN not in df.columns:
        raise KeyError(f"Missing label column: {LABEL_COLUMN}")

    group_column = resolve_group_column(df)

    print(f"[INFO] Loaded raw dataset: {RAW_FILE}")
    print(f"[INFO] Total rows: {len(df)}")
    print(f"[INFO] Group column: {group_column}")

    split_frames, manifest_rows = assign_groups_per_label(df, group_column)

    reset_split_dirs()

    split_dfs = {}
    for split_name in SPLITS:
        split_df = pd.concat(split_frames[split_name], ignore_index=True)
        split_dfs[split_name] = split_df
        save_split(split_df, split_name)

    manifest_df = pd.DataFrame(manifest_rows)
    manifest_df.to_csv(DATASET_DIR / "split_manifest.csv", index=False, encoding="utf-8")

    print("\n[DONE] V6 dataset split completed.")
    print(f"Train: {len(split_dfs['train'])}")
    print(f"Val:   {len(split_dfs['val'])}")
    print(f"Test:  {len(split_dfs['test'])}")

    print("\nPer-split class distribution:")
    for split_name in SPLITS:
        print_split_distribution(split_name, split_dfs[split_name], group_column)


if __name__ == "__main__":
    main()
