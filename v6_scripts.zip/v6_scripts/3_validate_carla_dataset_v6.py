from pathlib import Path

import pandas as pd


def resolve_v6_root() -> Path:
    script_path = Path(__file__).resolve()
    for parent in [script_path.parent, *script_path.parents]:
        if parent.name == "v6":
            return parent
    for parent in script_path.parents:
        candidate = parent / "v6"
        if candidate.exists():
            return candidate
    return script_path.parent / "v6"


V6_ROOT = resolve_v6_root()


def resolve_default_dataset_dir() -> Path:
    return V6_ROOT / "datasets" / "carla_tabular_dataset_v6"


DATASET_DIR = resolve_default_dataset_dir()
RAW_FILE = DATASET_DIR / "raw" / "carla_raw_dataset.csv"
SPLITS = ("train", "val", "test")

EXPECTED_ATTACKS = [
    "normal",
    "gps_spoofing",
    "position_spoofing",
    "speed_spoofing",
    "sudden_brake",
    "lane_deviation",
    "sensor_noise",
    "dos",
    "delayed_sensor_attack",
    "heading_spoofing",
]

GROUP_COLUMN_CANDIDATES = ("attack_run_id", "run_id", "scenario_id")

REQUIRED_COLUMNS = [
    "timestamp",
    "frame",
    "scenario_id",
    "run_id",
    "attack_run_id",
    "class_run_id",
    "tick_in_run",
    "vehicle_id",
    "map_name",
    "weather_preset",
    "npc_vehicle_count",
    "attack_type",
    "normal_subtype",
    "gps_spoof_subtype",
    "binary_label",
    "multiclass_label",
    "real_x",
    "real_y",
    "real_z",
    "real_speed",
    "real_accel",
    "real_yaw",
    "obs_x",
    "obs_y",
    "obs_z",
    "obs_speed",
    "obs_accel",
    "obs_yaw",
    "road_id",
    "lane_id",
    "throttle",
    "brake",
    "steer",
    "delta_pos_x",
    "delta_pos_y",
    "delta_speed",
    "delta_accel",
    "yaw_error",
    "is_missing",
    "nearest_vehicle_distance",
    "nearest_vehicle_relative_speed",
    "front_vehicle_distance",
    "rear_vehicle_distance",
    "nearby_vehicle_count",
    "traffic_density",
    "speed_change_rate",
    "acceleration_change_rate",
    "yaw_change_rate",
    "position_jump",
    "gps_drift_magnitude",
    "gps_drift_rate",
    "position_jump_magnitude",
    "position_jump_flag",
    "hard_brake_flag",
    "brake_intensity",
    "deceleration_rate",
    "time_since_brake_start",
    "speed_spoof_ratio",
    "speed_spoof_offset",
    "missing_ratio",
    "stale_packet_flag",
    "packet_delay_steps",
    "sensor_delay_steps",
    "delayed_sensor_flag",
    "heading_spoof_offset",
    "heading_spoof_flag",
]

OBSERVED_COLUMNS = [
    "obs_x",
    "obs_y",
    "obs_z",
    "obs_speed",
    "obs_accel",
    "obs_yaw",
]


def print_header(title):
    print("=" * 100)
    print(title)
    print("=" * 100)


def load_csv(file_path):
    df = pd.read_csv(file_path, low_memory=False)
    return df.replace("", pd.NA)


def resolve_group_column(df):
    for column_name in GROUP_COLUMN_CANDIDATES:
        if column_name in df.columns:
            return column_name
    raise KeyError(f"No run/group column found. Tried: {GROUP_COLUMN_CANDIDATES}")


def validate_columns(df, label):
    missing_columns = [column for column in REQUIRED_COLUMNS if column not in df.columns]
    extra_columns = [column for column in df.columns if column not in REQUIRED_COLUMNS]

    ok = True
    if missing_columns:
        ok = False
        print(f"[ERROR] {label}: missing columns -> {missing_columns}")
    if extra_columns:
        print(f"[INFO] {label}: extra columns -> {extra_columns}")
    return ok


def report_class_counts(df, group_column, title):
    print(f"\n{title}")
    counts = df["attack_type"].value_counts().sort_index()
    group_counts = df.groupby("attack_type")[group_column].nunique()
    for attack_name in EXPECTED_ATTACKS:
        count = int(counts.get(attack_name, 0))
        runs = int(group_counts.get(attack_name, 0))
        print(f"{attack_name:<24} rows={count:>6} runs={runs:>3}")


def report_missing_by_class(df, title):
    print(f"\n{title}")
    for attack_name in EXPECTED_ATTACKS:
        class_df = df[df["attack_type"] == attack_name]
        if class_df.empty:
            print(f"{attack_name:<24} rows=0")
            continue

        obs_missing_cells = int(class_df[OBSERVED_COLUMNS].isna().sum().sum())
        rows_with_missing = int(class_df[OBSERVED_COLUMNS].isna().any(axis=1).sum())
        avg_missing_ratio = float(class_df["missing_ratio"].fillna(0).mean())
        print(
            f"{attack_name:<24} rows={len(class_df):>5} "
            f"rows_with_missing={rows_with_missing:>5} "
            f"obs_missing_cells={obs_missing_cells:>5} "
            f"avg_missing_ratio={avg_missing_ratio:.3f}"
        )


def report_subtype_counts(df, subtype_column, title):
    print(f"\n{title}")
    counts = df[subtype_column].fillna("missing").value_counts().sort_index()
    for subtype_name, count in counts.items():
        print(f"{subtype_name:<32} rows={int(count):>6}")


def validate_subtype_columns(df):
    ok = True

    if "normal_subtype" in df.columns:
        normal_mask = df["attack_type"] == "normal"
        attack_mask = ~normal_mask
        if normal_mask.any() and (df.loc[normal_mask, "normal_subtype"] == "none").any():
            ok = False
            print("[ERROR] normal rows contain normal_subtype='none'.")
        if attack_mask.any() and (df.loc[attack_mask, "normal_subtype"] != "none").any():
            ok = False
            print("[ERROR] non-normal rows contain non-'none' normal_subtype values.")

    if "gps_spoof_subtype" in df.columns:
        gps_mask = df["attack_type"] == "gps_spoofing"
        non_gps_mask = ~gps_mask
        if gps_mask.any() and (df.loc[gps_mask, "gps_spoof_subtype"] == "none").any():
            ok = False
            print("[ERROR] gps_spoofing rows contain gps_spoof_subtype='none'.")
        if non_gps_mask.any() and (df.loc[non_gps_mask, "gps_spoof_subtype"] != "none").any():
            ok = False
            print("[ERROR] non-gps rows contain non-'none' gps_spoof_subtype values.")

    return ok


def validate_raw_dataset():
    print_header("CARLA TABULAR DATASET V6 - RAW REPORT")

    if not RAW_FILE.exists():
        print(f"[ERROR] Raw file not found: {RAW_FILE}")
        return False, None, None

    df = load_csv(RAW_FILE)
    group_column = resolve_group_column(df)
    ok = validate_columns(df, "raw")

    print(f"Dataset root : {DATASET_DIR}")
    print(f"Raw file     : {RAW_FILE}")
    print(f"Rows         : {len(df)}")
    print(f"Columns      : {len(df.columns)}")
    print(f"Group column : {group_column}")

    report_class_counts(df, group_column, "Raw class counts:")
    report_missing_by_class(df, "Raw missing-by-class:")
    report_subtype_counts(df[df["attack_type"] == "normal"], "normal_subtype", "Normal subtype counts:")
    report_subtype_counts(
        df[df["attack_type"] == "gps_spoofing"],
        "gps_spoof_subtype",
        "GPS spoof subtype counts:",
    )

    missing_attacks = [name for name in EXPECTED_ATTACKS if name not in set(df["attack_type"].unique())]
    if missing_attacks:
        ok = False
        print(f"\n[ERROR] Missing raw labels: {missing_attacks}")
    else:
        print("\n[OK] All expected raw labels exist.")

    if not validate_subtype_columns(df):
        ok = False
    else:
        print("[OK] Subtype column validation passed.")

    if ok:
        print("[OK] Raw schema validation passed.")

    return ok, df, group_column


def validate_split_dataset(raw_df, raw_group_column):
    print_header("CARLA TABULAR DATASET V6 - SPLIT REPORT")

    total_rows = 0
    overall_ok = True
    split_run_sets = {}

    for split_name in SPLITS:
        split_dir = DATASET_DIR / split_name
        print(f"\n[{split_name.upper()}]")

        if not split_dir.exists():
            overall_ok = False
            print(f"[ERROR] Missing split directory: {split_dir}")
            continue

        split_labels = set()
        split_rows = 0
        split_runs = set()

        for attack_name in EXPECTED_ATTACKS:
            data_file = split_dir / attack_name / "data.csv"
            if not data_file.exists():
                overall_ok = False
                print(f"[ERROR] Missing file: {data_file}")
                continue

            df = load_csv(data_file)
            group_column = resolve_group_column(df)
            if validate_columns(df, f"{split_name}/{attack_name}"):
                split_labels.add(attack_name)

            row_count = len(df)
            split_rows += row_count
            total_rows += row_count

            run_count = int(df[group_column].nunique())
            split_runs.update(df[group_column].dropna().astype(str).tolist())
            obs_missing_cells = int(df[OBSERVED_COLUMNS].isna().sum().sum())
            rows_with_missing = int(df[OBSERVED_COLUMNS].isna().any(axis=1).sum())

            print(
                f"{attack_name:<24} rows={row_count:>5} "
                f"runs={run_count:>3} "
                f"rows_with_missing={rows_with_missing:>5} "
                f"obs_missing_cells={obs_missing_cells:>5}"
            )

        missing_split_labels = [name for name in EXPECTED_ATTACKS if name not in split_labels]
        if missing_split_labels:
            overall_ok = False
            print(f"[ERROR] Missing labels in {split_name}: {missing_split_labels}")
        else:
            print(f"[OK] All expected labels exist in {split_name}.")

        split_run_sets[split_name] = split_runs
        print(f"[INFO] {split_name} total rows: {split_rows}")
        print(f"[INFO] {split_name} total runs: {len(split_runs)}")

    print("\n" + "=" * 100)
    print(f"Total rows across splits: {total_rows}")
    print("=" * 100)

    if raw_df is not None and total_rows != len(raw_df):
        overall_ok = False
        print(f"[ERROR] Raw/split row mismatch: raw={len(raw_df)} split_total={total_rows}")

    if len(split_run_sets) == len(SPLITS):
        overlaps = {
            "train_val": split_run_sets["train"] & split_run_sets["val"],
            "train_test": split_run_sets["train"] & split_run_sets["test"],
            "val_test": split_run_sets["val"] & split_run_sets["test"],
        }
        overlap_found = False
        for overlap_name, overlap_values in overlaps.items():
            if overlap_values:
                overlap_found = True
                overall_ok = False
                print(f"[ERROR] Run leakage detected in {overlap_name}: {sorted(overlap_values)[:10]}")

        if not overlap_found:
            print("[OK] No run/group overlap detected across splits.")

    if raw_df is not None and raw_group_column in raw_df.columns:
        raw_run_count = int(raw_df[raw_group_column].nunique())
        split_run_total = sum(len(split_run_sets.get(split_name, set())) for split_name in SPLITS)
        print(f"[INFO] Raw total runs: {raw_run_count}")
        print(f"[INFO] Split total runs: {split_run_total}")
        if raw_run_count != split_run_total:
            overall_ok = False
            print("[ERROR] Raw/split run-count mismatch.")

    if overall_ok:
        print("[OK] Split validation passed.")

    return overall_ok


def main():
    raw_ok, raw_df, raw_group_column = validate_raw_dataset()
    print()
    split_ok = validate_split_dataset(raw_df, raw_group_column)

    if not raw_ok or not split_ok:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
